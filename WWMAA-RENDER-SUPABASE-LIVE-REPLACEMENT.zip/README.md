# WWMAA Member Portal

React + Vite frontend for the World Wide Martial Arts Association. The current integration adds a Render-hosted Node API and uses the existing WWMAA-LIVE Supabase project for real account credentials and shared records. No sample members or dojos are preloaded.

See **[README-RENDER-SUPABASE-SETUP.md](README-RENDER-SUPABASE-SETUP.md)** for deployment and required secrets.

## Frontend

```sh
npm install
npm run build
```

Vercel project: `wwmaa-live` (`https://wwmaa-live.vercel.app`). Set `VITE_WWMAA_API_URL=https://wwmaa-api.onrender.com` in Vercel; this variable has already been added to the connected project.

## Backend

`backend/server.js` is the Express API. Render service `wwmaa-api` is connected to the existing `AKSHAY-WEB-ALLU/wwmaa` repository, branch `main`, with build command `cd backend && npm install` and start command `cd backend && npm start`.

The backend requires `SUPABASE_SERVICE_ROLE_KEY` in Render only, plus first-admin bootstrap credentials. Do not put the service role key in the frontend or commit it.
