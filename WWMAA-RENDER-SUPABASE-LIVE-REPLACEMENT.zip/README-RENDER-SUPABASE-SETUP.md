# WWMAA — Render + Supabase shared login

This version keeps the existing Vite/React website and replaces browser-only account login with a Render API backed by the existing `WWMAA-LIVE` Supabase project. Accounts created in the Control Panel are stored in Supabase Auth + `public.profiles`, so the same ID/password can be used on another phone. Shared app data is stored in `public.wwmaa_live_state` and the app polls the API every 5 seconds for changes. No demo users, demo dojos, or prefilled events are created. `src/users.json` is intentionally empty because the old file contained client-shipped passwords.

## 1. Deploy backend on Render

The Render Web Service `wwmaa-api` has already been created in your confirmed `My Workspace`, connected to `AKSHAY-WEB-ALLU/wwmaa` on branch `main`. Its first deployment failed because the current `main` branch does not yet contain `backend/server.js`. After you push this replacement source, Render auto-deploys. If you ever need to recreate it, use these settings:

- Name: `wwmaa-api`
- Branch: `main`
- Runtime: Node
- Build command: `cd backend && npm install`
- Start command: `cd backend && npm start`
- Region: Singapore
- Health check path: `/health`

Or use the included `render.yaml` as a Blueprint. Do not set the service root directory to `backend`; the commands already `cd backend`.

## 2. Render environment variables

Set these on the Render service, not in the frontend:

- `SUPABASE_URL` = `https://gmqcyotllnpgmlvorebl.supabase.co`
- `SUPABASE_ANON_KEY` = the Supabase publishable key from Project Settings → API Keys
- `SUPABASE_SERVICE_ROLE_KEY` = the Supabase secret/service-role key from Project Settings → API Keys. This is a server-only secret. Never add it to Vercel or commit it.
- `FRONTEND_ORIGIN` = `https://wwmaa-live.vercel.app`
- `BOOTSTRAP_ADMIN_ID` = the real first A Level admin ID you choose
- `BOOTSTRAP_ADMIN_PASSWORD` = a unique password of at least 12 characters that you choose
- `BOOTSTRAP_ADMIN_NAME` = your real admin display name

On startup, the backend creates that first A Level account only if `public.profiles` is empty. It does not create sample users. Once the first account is created, remove `BOOTSTRAP_ADMIN_PASSWORD` from Render to avoid retaining bootstrap credentials. The code protects the bootstrap account from deletion in the Control Panel.

## 3. Connect Vercel frontend

The variable below has already been added to Vercel project `wwmaa-live` for Production, Preview and Development. If it needs checking, open Vercel → project `wwmaa-live` → Settings → Environment Variables:

- `VITE_WWMAA_API_URL` = the deployed Render service URL, e.g. `https://wwmaa-api.onrender.com`

Add it to Production and Preview as needed, then redeploy the Vercel project. Do not add `SUPABASE_SERVICE_ROLE_KEY` to Vercel.

## 4. Supabase project

The backend uses the existing `WWMAA-LIVE` project and existing tables `profiles`, `students`, and `wwmaa_live_state`. This code uses the current `profiles`, `students`, and `wwmaa_live_state` schema and existing role policies. It does not insert demo records or run destructive migrations. I verified that `profiles` currently has zero rows, so the configured bootstrap admin can be created on the first successful backend startup.

## 5. Build locally before pushing

From the project root:

```sh
npm install
npm run build
```

To test the API locally, create `backend/.env` from `backend/.env.example`, install dependencies with `cd backend && npm install`, and run `npm start`. Never commit `.env`.

## Important

GitHub writes from the connected integration returned `403 Resource not accessible by integration`, so this workflow has not been pushed automatically. Upload/push this replacement to the existing repository. The Render API will not authenticate accounts until the server-only Supabase service key and initial admin bootstrap settings are configured. Render service dashboard: https://dashboard.render.com/web/srv-dbhiegu7bikc73enivjg. API URL: https://wwmaa-api.onrender.com. Vercel environment variable `VITE_WWMAA_API_URL` has been set, but the frontend must be redeployed after the replacement files are pushed.
