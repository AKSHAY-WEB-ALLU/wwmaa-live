import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import rateLimit from 'express-rate-limit'
import { createClient } from '@supabase/supabase-js'

const app = express()
const PORT = Number(process.env.PORT || 10000)
const SUPABASE_URL = process.env.SUPABASE_URL
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY
const ANON_KEY = process.env.SUPABASE_ANON_KEY
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || 'https://wwmaa-live.vercel.app'

app.set('trust proxy', 1)
app.use(helmet())
app.use(cors({
  origin(origin, callback) {
    if (!origin) return callback(null, true)
    const allowed = [FRONTEND_ORIGIN, 'https://wwmaa-live.vercel.app', 'https://wwmaa-live-git-main-akshayallu914-7429.vercel.app']
    if (allowed.includes(origin) || /^https:\/\/[a-z0-9-]+-akshayallu914-7429\.vercel\.app$/.test(origin)) return callback(null, true)
    return callback(new Error('Origin is not allowed by WWMAA API CORS policy.'))
  },
  methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}))
app.use(express.json({ limit: '1mb' }))
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }))
app.use('/api/admin', rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }))

const configured = Boolean(SUPABASE_URL && SERVICE_KEY && ANON_KEY)
const admin = configured ? createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false, autoRefreshToken: false } }) : null
const publicAuth = SUPABASE_URL && ANON_KEY ? createClient(SUPABASE_URL, ANON_KEY, { auth: { persistSession: false, autoRefreshToken: false } }) : null
const emailForId = id => `${String(id).trim().toLowerCase().replace(/[^a-z0-9._-]/g, '-') }@accounts.wwmaa.invalid`
const normalizeId = id => String(id || '').trim().toUpperCase()
const publicUser = p => ({ id: p.account_id, name: p.full_name, role: p.role, status: p.active ? 'Active' : 'Inactive', dojo: p.dojo || '', belt: p.belt || 'White Belt', style: p.discipline || 'Karate', passwordSet: true })

function requireConfigured(req, res, next) {
  if (!configured) return res.status(503).json({ error: 'WWMAA backend is not configured. Add SUPABASE_URL, SUPABASE_ANON_KEY and SUPABASE_SERVICE_ROLE_KEY to Render environment variables.' })
  next()
}
async function getActor(req) {
  const header = req.headers.authorization || ''
  const token = header.startsWith('Bearer ') ? header.slice(7) : ''
  if (!token) throw Object.assign(new Error('Please sign in again.'), { status: 401 })
  const { data: authData, error: authError } = await admin.auth.getUser(token)
  if (authError || !authData?.user) throw Object.assign(new Error('Your session is invalid or expired. Please sign in again.'), { status: 401 })
  const { data: profile, error } = await admin.from('profiles').select('*').eq('id', authData.user.id).maybeSingle()
  if (error) throw Object.assign(new Error('Could not load WWMAA profile.'), { status: 500 })
  if (!profile || !profile.active) throw Object.assign(new Error('This account is inactive or has not been provisioned.'), { status: 403 })
  return { authUser: authData.user, profile, token }
}
async function actorMiddleware(req, res, next) {
  try { req.actor = await getActor(req); next() }
  catch (error) { res.status(error.status || 500).json({ error: error.message || 'Authentication failed.' }) }
}
function canManageUsers(actorRole, targetRole) {
  return actorRole === 'A Level' || (actorRole === 'B Level' && targetRole === 'Senpai')
}
function validRole(role) { return ['A Level', 'B Level', 'Sensei', 'Sensi', 'Senpai', 'Student'].includes(role) }

app.get('/health', (_req, res) => res.json({ ok: true, service: 'wwmaa-api', configured }))
app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'wwmaa-api', configured }))

// First admin is provisioned only when the profiles table is empty and the three
// bootstrap variables are configured in Render. No demo users are inserted.
async function bootstrapFirstAdmin() {
  if (!configured || !process.env.BOOTSTRAP_ADMIN_ID || !process.env.BOOTSTRAP_ADMIN_PASSWORD) return
  const { count, error: countError } = await admin.from('profiles').select('id', { count: 'exact', head: true })
  if (countError || count !== 0) return
  const id = normalizeId(process.env.BOOTSTRAP_ADMIN_ID)
  const password = process.env.BOOTSTRAP_ADMIN_PASSWORD
  if (!id || password.length < 12) {
    console.error('Bootstrap admin not created: set BOOTSTRAP_ADMIN_ID and a BOOTSTRAP_ADMIN_PASSWORD of at least 12 characters.')
    return
  }
  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email: emailForId(id), password, email_confirm: true,
    user_metadata: { account_id: id, full_name: process.env.BOOTSTRAP_ADMIN_NAME || 'WWMAA Administrator' },
  })
  if (createError) { console.error('Bootstrap admin auth creation failed:', createError.message); return }
  const { error: profileError } = await admin.from('profiles').insert({
    id: created.user.id, account_id: id, full_name: process.env.BOOTSTRAP_ADMIN_NAME || 'WWMAA Administrator',
    role: 'A Level', dojo: '', discipline: 'All', belt: 'Black Belt', active: true,
  })
  if (profileError) {
    await admin.auth.admin.deleteUser(created.user.id)
    console.error('Bootstrap admin profile creation failed:', profileError.message)
    return
  }
  console.log('WWMAA first administrator provisioned from Render bootstrap settings.')
}

app.post('/api/auth/login', requireConfigured, async (req, res) => {
  try {
    const id = normalizeId(req.body?.id)
    const password = String(req.body?.password || '')
    const loginMode = req.body?.loginMode === 'admin' ? 'admin' : 'student'
    const previewRole = String(req.body?.previewRole || 'A Level')
    if (!id || !password) return res.status(400).json({ error: 'Enter your association ID and password.' })
    const { data: profile, error: profileError } = await admin.from('profiles').select('*').eq('account_id', id).maybeSingle()
    if (profileError) return res.status(500).json({ error: 'Unable to check this account.' })
    if (!profile || !profile.active) return res.status(401).json({ error: 'ID or password is incorrect, or this account is inactive.' })
    const isAdmin = ['A Level', 'B Level'].includes(profile.role)
    if ((loginMode === 'admin' && !isAdmin) || (loginMode === 'student' && isAdmin)) return res.status(403).json({ error: 'Choose the correct login tab for this account.' })
    if (loginMode === 'admin' && profile.role !== previewRole) return res.status(403).json({ error: `This account is ${profile.role}. Select ${profile.role} in the Admin Access Level dropdown.` })
    const { data, error } = await publicAuth.auth.signInWithPassword({ email: emailForId(id), password })
    if (error || !data?.session) return res.status(401).json({ error: 'ID or password is incorrect.' })
    return res.json({ accessToken: data.session.access_token, expiresAt: data.session.expires_at, user: publicUser(profile) })
  } catch (error) { console.error('login error', error.message); res.status(500).json({ error: 'Login failed. Please try again.' }) }
})

app.get('/api/auth/me', requireConfigured, actorMiddleware, (req, res) => res.json({ user: publicUser(req.actor.profile) }))

app.get('/api/admin/users', requireConfigured, actorMiddleware, async (req, res) => {
  if (!['A Level', 'B Level'].includes(req.actor.profile.role)) return res.status(403).json({ error: 'Administrator access required.' })
  let query = admin.from('profiles').select('*').order('created_at', { ascending: true })
  if (req.actor.profile.role === 'B Level') query = query.eq('role', 'Senpai')
  const { data, error } = await query
  if (error) return res.status(500).json({ error: 'Unable to load accounts.' })
  res.json({ users: (data || []).map(publicUser) })
})

app.post('/api/admin/users', requireConfigured, actorMiddleware, async (req, res) => {
  const actor = req.actor.profile
  if (actor.role !== 'A Level') return res.status(403).json({ error: 'Only A Level administrators can create accounts.' })
  const id = normalizeId(req.body?.id)
  const name = String(req.body?.name || '').trim()
  const role = String(req.body?.role || 'Student')
  const password = String(req.body?.password || '')
  const dojo = String(req.body?.dojo || '').trim()
  const belt = String(req.body?.belt || 'White Belt').trim()
  const discipline = String(req.body?.style || req.body?.discipline || 'Karate')
  if (!id || !name) return res.status(400).json({ error: 'Login ID and full name are required.' })
  if (!validRole(role)) return res.status(400).json({ error: 'Invalid WWMAA role.' })
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' })
  const { data: existing } = await admin.from('profiles').select('id').eq('account_id', id).maybeSingle()
  if (existing) return res.status(409).json({ error: 'That login ID already exists.' })
  const { data: authData, error: authError } = await admin.auth.admin.createUser({ email: emailForId(id), password, email_confirm: true, user_metadata: { account_id: id, full_name: name } })
  if (authError || !authData?.user) return res.status(400).json({ error: authError?.message || 'Could not create login credentials.' })
  const { data: profile, error: profileError } = await admin.from('profiles').insert({ id: authData.user.id, account_id: id, full_name: name, role, dojo: dojo || null, discipline, belt, active: true }).select('*').single()
  if (profileError) {
    await admin.auth.admin.deleteUser(authData.user.id)
    return res.status(400).json({ error: profileError.message.includes('duplicate') ? 'That login ID already exists.' : 'Could not save the new member profile.' })
  }
  if (role === 'Student' || role === 'Senpai' || role === 'Sensei' || role === 'Sensi') {
    const { error: studentError } = await admin.from('students').upsert({ member_id: id, name, dojo_name: dojo, belt, discipline, details: { role } }, { onConflict: 'member_id' })
    if (studentError) console.error('profile saved; student directory sync warning:', studentError.message)
  }
  res.status(201).json({ user: publicUser(profile) })
})

app.patch('/api/admin/users/:id', requireConfigured, actorMiddleware, async (req, res) => {
  const actor = req.actor.profile
  const originalId = normalizeId(req.params.id)
  const { data: target, error: targetError } = await admin.from('profiles').select('*').eq('account_id', originalId).maybeSingle()
  if (targetError || !target) return res.status(404).json({ error: 'Account not found.' })
  if (!canManageUsers(actor.role, target.role)) return res.status(403).json({ error: 'You cannot edit this account.' })
  const nextRole = actor.role === 'B Level' ? target.role : String(req.body?.role || target.role)
  if (!validRole(nextRole)) return res.status(400).json({ error: 'Invalid WWMAA role.' })
  const nextId = normalizeId(req.body?.id || target.account_id)
  const updates = {
    account_id: nextId,
    full_name: String(req.body?.name ?? target.full_name).trim(),
    role: nextRole,
    dojo: String(req.body?.dojo ?? target.dojo ?? '').trim() || null,
    belt: String(req.body?.belt ?? target.belt ?? 'White Belt').trim(),
    discipline: String(req.body?.style ?? req.body?.discipline ?? target.discipline ?? 'Karate'),
  }
  if (!updates.account_id || !updates.full_name) return res.status(400).json({ error: 'Login ID and full name are required.' })
  if (req.body?.password && String(req.body.password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' })
  if (nextId !== originalId) {
    const { data: duplicate } = await admin.from('profiles').select('id').eq('account_id', nextId).maybeSingle()
    if (duplicate) return res.status(409).json({ error: 'That login ID already exists.' })
  }
  const { error: updateAuthError } = await admin.auth.admin.updateUserById(target.id, {
    ...(req.body?.password ? { password: String(req.body.password) } : {}),
    email: emailForId(nextId), user_metadata: { account_id: nextId, full_name: updates.full_name },
  })
  if (updateAuthError) return res.status(400).json({ error: 'Could not update authentication details.' })
  const { data: updated, error } = await admin.from('profiles').update(updates).eq('id', target.id).select('*').single()
  if (error) return res.status(400).json({ error: 'Could not update account profile. Try again.' })
  await admin.from('students').update({ member_id: nextId, name: updates.full_name, dojo_name: updates.dojo || '', belt: updates.belt, discipline: updates.discipline }).eq('member_id', originalId)
  res.json({ user: publicUser(updated) })
})

app.delete('/api/admin/users/:id', requireConfigured, actorMiddleware, async (req, res) => {
  if (req.actor.profile.role !== 'A Level') return res.status(403).json({ error: 'Only A Level administrators can delete accounts.' })
  const id = normalizeId(req.params.id)
  if (id === normalizeId(process.env.BOOTSTRAP_ADMIN_ID)) return res.status(403).json({ error: 'The bootstrap administrator cannot be deleted through this screen.' })
  const { data: profile, error } = await admin.from('profiles').select('id,account_id').eq('account_id', id).maybeSingle()
  if (error || !profile) return res.status(404).json({ error: 'Account not found.' })
  const { error: deleteError } = await admin.auth.admin.deleteUser(profile.id)
  if (deleteError) return res.status(400).json({ error: 'Could not delete account.' })
  res.json({ ok: true })
})


const STATE_KEYS = new Set(['students', 'events', 'announcements', 'dojos', 'surveys', 'attendance:all', 'fees:all', 'grading:all'])
function canReadState(role, accountId, key) {
  if (['events', 'announcements', 'dojos', 'surveys'].includes(key)) return true
  if (key === 'students') return ['A Level','B Level','Sensei','Sensi','Senpai'].includes(role)
  if (key.startsWith('students:')) return ['A Level','B Level','Sensei','Sensi','Senpai'].includes(role) || key === `students:${accountId}`
  if (key === 'attendance:all') return ['A Level','B Level','Sensei','Sensi'].includes(role)
  if (key.startsWith('attendance:')) return ['A Level','B Level','Sensei','Sensi'].includes(role) || key === `attendance:${accountId}`
  if (key === 'fees:all') return role === 'A Level'
  if (key.startsWith('fees:')) return role === 'A Level' || key === `fees:${accountId}`
  if (key === 'grading:all') return ['A Level','Sensei','Sensi'].includes(role)
  if (key.startsWith('grading:')) return ['A Level','Sensei','Sensi'].includes(role) || key === `grading:${accountId}`
  if (key.startsWith('survey-response:')) return ['A Level','B Level'].includes(role) || key.endsWith(`:${accountId}`)
  return false
}
function canWriteState(role, accountId, key) {
  if (key === 'students') return role === 'A Level'
  if (key === 'events' || key === 'dojos' || key === 'fees:all' || key === 'grading:all') return role === 'A Level'
  if (key === 'announcements' || key === 'surveys') return ['A Level','B Level'].includes(role)
  if (key === 'attendance:all') return ['A Level','B Level','Sensei','Sensi'].includes(role)
  if (key.startsWith('students:')) return role === 'A Level'
  if (key.startsWith('attendance:')) return ['A Level','B Level','Sensei','Sensi'].includes(role) || (role === 'Senpai' && key === `attendance:${accountId}`)
  if (key.startsWith('fees:')) return role === 'A Level'
  if (key.startsWith('grading:')) return role === 'A Level'
  if (key.startsWith('survey-response:')) return ['A Level','B Level'].includes(role) || key.endsWith(`:${accountId}`)
  return false
}

app.get('/api/state', requireConfigured, actorMiddleware, async (req, res) => {
  const { role, account_id: accountId } = req.actor.profile
  const { data, error } = await admin.from('wwmaa_live_state').select('state_key,payload,updated_at').order('updated_at', { ascending: false })
  if (error) return res.status(500).json({ error: 'Could not load shared WWMAA data.' })
  const states = {}
  const allRows = new Map((data || []).map(row => [row.state_key, row]))
  for (const row of data || []) if (canReadState(role, accountId, row.state_key)) states[row.state_key] = { payload: row.payload, updated_at: row.updated_at }

  // Derive member-scoped views from the shared admin/instructor ledgers. This
  // keeps the data shared without exposing every member's private records.
  if (!['A Level','B Level','Sensei','Sensi','Senpai'].includes(role)) {
    const row = allRows.get('students')
    if (row && Array.isArray(row.payload)) states[`students:${accountId}`] = {
      payload: row.payload.filter(item => String(item.id || item.member_id || '').toUpperCase() === String(accountId).toUpperCase()), updated_at: row.updated_at,
    }
  }
  if (!['A Level','B Level','Sensei','Sensi'].includes(role)) {
    const row = allRows.get('attendance:all')
    if (row && Array.isArray(row.payload)) states[`attendance:${accountId}`] = {
      payload: row.payload.filter(item => item.statuses && Object.prototype.hasOwnProperty.call(item.statuses, accountId)), updated_at: row.updated_at,
    }
  }
  if (role !== 'A Level') {
    const row = allRows.get('fees:all')
    if (row && Array.isArray(row.payload)) states[`fees:${accountId}`] = {
      payload: row.payload.filter(item => String(item.memberId || item.member_id || '').toUpperCase() === String(accountId).toUpperCase()), updated_at: row.updated_at,
    }
  }
  if (!['A Level','Sensei','Sensi'].includes(role)) {
    const row = allRows.get('grading:all')
    if (row && Array.isArray(row.payload)) states[`grading:${accountId}`] = {
      payload: row.payload.filter(item => String(item.memberId || item.member_id || '').toUpperCase() === String(accountId).toUpperCase()), updated_at: row.updated_at,
    }
  }
  res.json({ states })
})

app.put('/api/state/:key', requireConfigured, actorMiddleware, async (req, res) => {
  const { profile, authUser } = req.actor
  const key = decodeURIComponent(req.params.key)
  const allowed = STATE_KEYS.has(key) || /^(students|attendance|fees|grading):[A-Z0-9._-]+$/.test(key) || /^survey-response:[A-Z0-9._-]+:[A-Z0-9._-]+$/.test(key)
  if (!allowed) return res.status(400).json({ error: 'Invalid shared-state key.' })
  if (!canWriteState(profile.role, profile.account_id, key)) return res.status(403).json({ error: 'Your role cannot change this shared data.' })
  if (req.body?.payload === undefined || req.body?.payload === null || typeof req.body.payload !== 'object') return res.status(400).json({ error: 'A JSON object or array payload is required.' })
  const { data, error } = await admin.from('wwmaa_live_state').upsert({
    state_key: key, payload: req.body.payload, updated_by: authUser.id, updated_at: new Date().toISOString(), origin_id: req.headers['x-wwmaa-origin'] || null,
  }, { onConflict: 'state_key' }).select('state_key,updated_at').single()
  if (error) return res.status(400).json({ error: 'Could not save shared WWMAA data.' })
  res.json({ ok: true, state_key: data.state_key, updated_at: data.updated_at })
})

app.use((error, _req, res, _next) => {
  if (error.message?.includes('CORS')) return res.status(403).json({ error: error.message })
  console.error('Unhandled API error:', error.message)
  res.status(500).json({ error: 'Unexpected server error.' })
})

app.listen(PORT, '0.0.0.0', async () => {
  console.log(`WWMAA API listening on ${PORT}; Supabase configured: ${configured}`)
  try { await bootstrapFirstAdmin() } catch (error) { console.error('Bootstrap attempt failed:', error.message) }
})
