import React, { useEffect, useMemo, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  Shield, Users, CalendarDays, ClipboardCheck, MapPin, Settings, LogOut,
  Search, Plus, ChevronRight, Bell, Menu, X, Swords, Trophy, UserRound,
  Building2, Eye, Pencil, KeyRound, CircleHelp, Check, Clock3, Receipt, GraduationCap, Megaphone, BarChart3, Download, FileText, ListChecks, FileSpreadsheet
} from 'lucide-react'
import './styles.css'
import DownloadLanding from './DownloadLanding.jsx'
import { loginWWMAA, wwmaaRequest } from './wwmaa-api.js'

const initialStudents = []
const initialEvents = []
const navItems = [
  ['Overview', 'overview', Shield], ['Student details', 'students', Users],
  ['Attendance', 'attendance', ClipboardCheck], ['Upcoming events', 'events', CalendarDays],
  ['Dojos', 'dojos', MapPin], ['Fees & payments', 'fees', Receipt], ['Belt progression', 'grading', GraduationCap], ['Announcements', 'announcements', Megaphone], ['Tournament surveys', 'surveys', ListChecks], ['Reports', 'reports', BarChart3], ['Control panel', 'control', Settings]
]

function announcementVisibleForSession(item, session) { if (!session) return false; const a=item.audience||'All members'; const roleMatch=['Everyone','All members'].includes(a)||(a==='Students'&&session.role==='Student')||(a==='Senpais'&&session.role==='Senpai')||(a==='Senseis'&&['Sensei','Sensi'].includes(session.role))||(a==='Administrators'&&['A Level','B Level'].includes(session.role))||a===session.role; return roleMatch&&(!item.dojo||item.dojo==='All dojos'||item.dojo===session.dojo) }

function App() {
  const [session, setSession] = useState(() => {
    try { const saved = JSON.parse(localStorage.getItem('wwmaa-v13-remembered-session') || 'null'); return saved?.accessToken ? saved : null } catch { return null }
  })
  const [rememberMe, setRememberMe] = useState(true)
  const [userAccounts, setUserAccounts] = useState([])
  const [loginId, setLoginId] = useState('')
  const [passcode, setPasscode] = useState('')
  const [previewRole, setPreviewRole] = useState('A Level')
  const [loginMode, setLoginMode] = useState('student')
  const [active, setActive] = useState('overview')
  const [mobileNav, setMobileNav] = useState(false)
  const [students, setStudents] = useState(initialStudents)
  const [attendanceRecords, setAttendanceRecords] = useState([])
  const [events, setEvents] = useState(initialEvents)
  const [feeRecords, setFeeRecords] = useState([])
  const [gradingRecords, setGradingRecords] = useState([])
  const [announcements, setAnnouncements] = useState([])
  const [surveys, setSurveys] = useState([])
  const [dojos, setDojos] = useState([])
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [eventType, setEventType] = useState('All')
  const [showStudentForm, setShowStudentForm] = useState(false)
  const [showEventForm, setShowEventForm] = useState(false)
  const [notice, setNotice] = useState('')
  const [remoteStateReady, setRemoteStateReady] = useState(false)
  const applyingRemoteState = useRef(false)
  const remoteSnapshot = useRef({})
  const [newStudent, setNewStudent] = useState({ name: '', id: '', dojo: '', belt: 'White Belt', role: 'Student', style: 'Karate', eventId: '' })
  const [activeEventId, setActiveEventId] = useState('1')
  const [newEvent, setNewEvent] = useState({ title: '', type: 'Karate', date: '', time: '', place: '' })
  const role = session?.role || 'Student / Senpai / Sensei'
  const isSensei = ['Sensi','Sensei'].includes(role)
  const discipline = session?.discipline || 'All'
  const restrictedSenpai = role === 'Senpai'
  const isA = role === 'A Level'
  const isB = role === 'B Level'
  const canManage = isA
  const canManageEverything = isA || isB
  const filteredStudents = useMemo(() => students.filter(s => { const text = `${s.name} ${s.id} ${s.dojo} ${s.belt}`.toLowerCase().includes(query.toLowerCase()); const styleOK = isSensei || discipline === 'All' || (s.style || 'Karate').toLowerCase() === discipline.toLowerCase(); const dojoOK = !restrictedSenpai || s.dojo === session?.dojo; return text && styleOK && dojoOK }), [students, query, discipline, isSensei, restrictedSenpai, session?.dojo])
  const filteredEvents = useMemo(() => events.filter(e => (eventType === 'All' || e.type === eventType) && (isSensei || discipline === 'All' || e.type.toLowerCase() === discipline.toLowerCase()) && (!restrictedSenpai || e.place === session?.dojo)), [events, eventType, discipline, isSensei, restrictedSenpai, session?.dojo])

  useEffect(() => {
    if (!session?.accessToken || !['A Level', 'B Level'].includes(session.role)) { setUserAccounts([]); return }
    let alive = true
    const refresh = async () => {
      try {
        const data = await wwmaaRequest('/api/admin/users', { token: session.accessToken })
        if (alive) setUserAccounts(Array.isArray(data.users) ? data.users : [])
      } catch (error) {
        if (alive && /token|session|unauthorized|expired/i.test(error.message)) {
          localStorage.removeItem('wwmaa-v13-remembered-session')
          setSession(null)
          setNotice('Your secure session expired. Please sign in again.')
        }
      }
    }
    void refresh()
    const timer = window.setInterval(refresh, 10000)
    return () => { alive = false; window.clearInterval(timer) }
  }, [session?.accessToken, session?.role])

  async function refreshAccounts() {
    if (!session?.accessToken) return
    const data = await wwmaaRequest('/api/admin/users', { token: session.accessToken })
    setUserAccounts(Array.isArray(data.users) ? data.users : [])
  }
  async function createAccount(account) {
    const data = await wwmaaRequest('/api/admin/users', { method: 'POST', token: session.accessToken, body: account })
    const user = data.user
    if (!['A Level', 'B Level'].includes(user.role)) setStudents(prev => prev.some(item => String(item.id).toLowerCase() === String(user.id).toLowerCase()) ? prev.map(item => String(item.id).toLowerCase() === String(user.id).toLowerCase() ? { ...item, id: user.id, name: user.name, dojo: user.dojo, belt: user.belt, role: user.role, style: user.style } : item) : [...prev, { id: user.id, name: user.name, dojo: user.dojo, belt: user.belt, role: user.role, style: user.style }])
    await refreshAccounts()
    return data
  }
  async function updateAccount(accountId, account) {
    const data = await wwmaaRequest(`/api/admin/users/${encodeURIComponent(accountId)}`, { method: 'PATCH', token: session.accessToken, body: account })
    const user = data.user
    if (!['A Level', 'B Level'].includes(user.role)) setStudents(prev => prev.map(item => String(item.id).toLowerCase() === String(accountId).toLowerCase() ? { ...item, id: user.id, name: user.name, dojo: user.dojo, belt: user.belt, role: user.role, style: user.style } : item))
    await refreshAccounts()
    return data
  }
  async function deleteAccount(accountId) {
    const data = await wwmaaRequest(`/api/admin/users/${encodeURIComponent(accountId)}`, { method: 'DELETE', token: session.accessToken })
    setStudents(prev => prev.filter(item => String(item.id).toLowerCase() !== String(accountId).toLowerCase()))
    await refreshAccounts()
    return data
  }


  useEffect(() => {
    if (!session?.accessToken) { setRemoteStateReady(false); return }
    let alive = true
    const pullState = async () => {
      try {
        const data = await wwmaaRequest('/api/state', { token: session.accessToken })
        if (!alive) return
        const states = data.states || {}
        applyingRemoteState.current = true
        for (const [key, value] of Object.entries(states)) remoteSnapshot.current[key] = JSON.stringify(value.payload)
        const assignIfDifferent = (key, setter, fallbackKey = key) => {
          const item = states[fallbackKey]
          if (!item || item.payload === undefined) return
          setter(previous => JSON.stringify(previous) === JSON.stringify(item.payload) ? previous : item.payload)
        }
        assignIfDifferent('students', setStudents, ['A Level','B Level','Sensei','Sensi','Senpai'].includes(session.role) ? 'students' : `students:${session.id}`)
        assignIfDifferent('events', setEvents)
        assignIfDifferent('announcements', setAnnouncements)
        assignIfDifferent('dojos', setDojos)
        assignIfDifferent('surveys', setSurveys)
        assignIfDifferent('attendance', setAttendanceRecords, ['A Level','B Level','Sensei','Sensi'].includes(session.role) ? 'attendance:all' : `attendance:${session.id}`)
        assignIfDifferent('fees', setFeeRecords, session.role === 'A Level' ? 'fees:all' : `fees:${session.id}`)
        assignIfDifferent('grading', setGradingRecords, ['A Level','Sensei','Sensi'].includes(session.role) ? 'grading:all' : `grading:${session.id}`)
        setRemoteStateReady(true)
        queueMicrotask(() => { applyingRemoteState.current = false })
      } catch (error) {
        if (alive && /token|session|unauthorized|expired/i.test(error.message)) {
          localStorage.removeItem('wwmaa-v13-remembered-session')
          setSession(null)
          setNotice('Your secure session expired. Please sign in again.')
        }
      }
    }
    void pullState()
    const timer = window.setInterval(pullState, 5000)
    return () => { alive = false; window.clearInterval(timer) }
  }, [session?.accessToken, session?.id, session?.role])

  useEffect(() => {
    if (!session?.accessToken || !remoteStateReady || applyingRemoteState.current) return
    const role = session.role
    const statePayloads = []
    if (role === 'A Level') statePayloads.push(['students', students], ['events', events], ['dojos', dojos], ['fees:all', feeRecords], ['grading:all', gradingRecords])
    if (['A Level', 'B Level'].includes(role)) statePayloads.push(['announcements', announcements], ['surveys', surveys])
    if (['A Level', 'B Level', 'Sensei', 'Sensi'].includes(role)) statePayloads.push(['attendance:all', attendanceRecords])
    if (role === 'Senpai') statePayloads.push([`attendance:${session.id}`, attendanceRecords])
    const timer = window.setTimeout(async () => {
      for (const [key, payload] of statePayloads) {
        const encoded = JSON.stringify(payload)
        if (remoteSnapshot.current[key] === encoded) continue
        if (remoteSnapshot.current[key] === undefined && (!Array.isArray(payload) || payload.length === 0)) continue
        try {
          await wwmaaRequest(`/api/state/${encodeURIComponent(key)}`, { method: 'PUT', token: session.accessToken, body: { payload } })
          remoteSnapshot.current[key] = encoded
        } catch (error) { if (!/permission|forbidden|not allowed|403/i.test(error.message)) console.warn('[WWMAA sync]', key, error.message) }
      }
    }, 500)
    return () => window.clearTimeout(timer)
  }, [session?.accessToken, session?.id, session?.role, remoteStateReady, students, events, announcements, dojos, surveys, attendanceRecords, feeRecords, gradingRecords])

  async function login(e) {
    e.preventDefault()
    if (!loginId.trim() || !passcode.trim()) { setNotice('Enter your ID and password to continue.'); return }
    setNotice('Connecting securely…')
    try {
      const result = await loginWWMAA({ id: loginId.trim(), password: passcode, loginMode, previewRole })
      const account = result.user
      const nextSession = { ...account, loginMode, accessToken: result.accessToken }
      setRemoteStateReady(false)
      setSession(nextSession)
      if (!['A Level', 'B Level'].includes(account.role)) setStudents(prev => prev.some(item => String(item.id).toLowerCase() === String(account.id).toLowerCase()) ? prev : [...prev, { id: account.id, name: account.name, dojo: account.dojo || '', belt: account.belt || 'White Belt', role: account.role, style: account.style || 'Karate' }])
      if (rememberMe) localStorage.setItem('wwmaa-v13-remembered-session', JSON.stringify(nextSession))
      else localStorage.removeItem('wwmaa-v13-remembered-session')
      setUserAccounts([])
      setActive('overview')
      setNotice('')
      setPasscode('')
    } catch (error) {
      setNotice(error.message || 'Unable to sign in. Check your ID and password.')
    }
  }
  function addStudent(e) {
    e.preventDefault()
    if (!newStudent.name.trim() || !newStudent.id.trim()) return
    setStudents(prev => { const next = [...prev, { ...newStudent, style: newStudent.style, eventId: newStudent.eventId ? Number(newStudent.eventId) : null }]; return next })
    setNewStudent({ name: '', id: '', dojo: '', belt: 'White Belt', role: 'Student', style: 'Karate', eventId: '' })
    setShowStudentForm(false)
    setNotice('Student profile added in this shared WWMAA database.')
  }
  function addEvent(e) {
    e.preventDefault()
    if (!newEvent.title.trim() || !newEvent.date) return
    setEvents(prev => { const next = [...prev, { ...newEvent, id: Date.now(), status: 'Upcoming' }]; return next })
    setNewEvent({ title: '', type: 'Karate', date: '', time: '', place: '' })
    setShowEventForm(false)
    setNotice('Event added in this shared WWMAA database.')
  }

  if (!session) return <Login login={login} loginId={loginId} setLoginId={setLoginId} passcode={passcode} setPasscode={setPasscode} previewRole={previewRole} setPreviewRole={setPreviewRole} loginMode={loginMode} setLoginMode={setLoginMode} notice={notice} rememberMe={rememberMe} setRememberMe={setRememberMe} />

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}>
      <div className="brand">
        <img src="/logo.png" alt="WWMAA crest" onError={e => e.currentTarget.style.display='none'} />
        <div><b>WWMAA</b><span>MEMBER PORTAL</span></div>
        <button className="icon-btn close-nav" onClick={() => setMobileNav(false)}><X size={19}/></button>
      </div>
      <div className="association-tag"><span className="red-dot"/> WORLD WIDE MARTIAL ARTS ASSOCIATION</div>
      <div className="nav-label">WORKSPACE</div>
      <nav>{navItems.filter(([label, key]) => (label !== 'Control panel' || canManageEverything) && (!restrictedSenpai || ['Overview','Student details','Attendance','Upcoming events','Dojos','Announcements','Tournament surveys'].includes(label)) && (session.loginMode !== 'student' || isSensei || ['Overview','Student details','Attendance','Upcoming events','Fees & payments','Belt progression','Announcements','Dojos','Tournament surveys'].includes(label))).map(([label, key, Icon]) =>
        <button key={key} className={`nav-link ${active === key ? 'active' : ''}`} onClick={() => {setActive(key);setMobileNav(false)}}>
          <Icon size={18}/><span>{label}</span>{active === key && <ChevronRight size={15} className="nav-chevron"/>}
        </button>
      )}</nav>
      <div className="sidebar-bottom">
        <div className="role-card"><div className="role-icon"><Shield size={18}/></div><div><small>ACCESS LEVEL</small><strong>{role}</strong></div><span className="online-dot"/></div>
        <button className="nav-link logout" onClick={() => {setSession(null);setUserAccounts([]);localStorage.removeItem('wwmaa-v13-remembered-session');setPasscode('');setLoginId('')}}><LogOut size={18}/><span>Sign out</span></button>
        <small className="version">WWMAA PORTAL · V13</small>
      </div>
    </aside>
    {mobileNav && <div className="scrim" onClick={() => setMobileNav(false)} />}
    <main className="main-area">
      <header className="topbar">
        <button className="icon-btn menu-btn" onClick={() => setMobileNav(true)}><Menu size={21}/></button>
        <div className="breadcrumb">Portal <span>/</span> <b>{navItems.find(n => n[1] === active)?.[0] || 'Overview'}</b></div>
        <div className="top-actions"><label className="top-event-select"><span>EVENT</span><select aria-label="Current association event" value={activeEventId} onChange={e=>setActiveEventId(e.target.value)}><option value="">No event selected</option>{events.filter(e=>isSensei||discipline==='All'||e.type.toLowerCase()===discipline.toLowerCase()).map(e=><option key={e.id} value={String(e.id)}>{e.title}</option>)}</select></label><span className="status-pill"><i/> Association portal</span><div className="notification-wrap"><button className="icon-btn notification" aria-label="Notifications" onClick={()=>setNotificationsOpen(v=>!v)}><Bell size={18}/>{announcements.some(a=>announcementVisibleForSession(a,session))&&<i/>}</button>{notificationsOpen&&<div className="notification-popover"><div className="notification-head"><b>Notifications</b><button className="text-button" onClick={()=>{setNotificationsOpen(false);setActive('announcements')}}>View all</button></div>{announcements.filter(a=>announcementVisibleForSession(a,session)).slice(0,5).map(a=><button className="notification-item" key={a.id} onClick={()=>{setNotificationsOpen(false);setActive('announcements')}}><strong>{a.title}</strong><small>{a.dojo||'All dojos'} · {a.date}</small><span>{a.body}</span></button>)}{!announcements.some(a=>announcementVisibleForSession(a,session))&&<p className="notification-empty">You are all caught up.</p>}</div>}</div><div className="avatar">{session.id.slice(0,2).toUpperCase()}</div><div className="user-meta"><b>{session.id}</b><small>{role}</small></div></div>
      </header>
      <div className="page-content">
        {notice && <div className="notice"><Check size={16}/>{notice}<button onClick={() => setNotice('')}><X size={15}/></button></div>}
        {active === 'overview' && <Overview role={role} students={filteredStudents} events={filteredEvents} setActive={setActive} />}
         {active === 'students' && ((session.loginMode === 'student' && !isSensei) ? <StudentProfile session={session} students={students} events={filteredEvents} /> : <Students students={restrictedSenpai ? filteredStudents.filter(s=>s.id===session.id || s.role==='Student' || s.role==='Senpai') : filteredStudents} query={query} setQuery={setQuery} canManage={canManage} isA={isA} setShowStudentForm={setShowStudentForm} />)}
         {active === 'attendance' && ((session.loginMode === 'student' && !isSensei) ? <StudentAttendance session={session} students={students} attendanceRecords={attendanceRecords} /> : <Attendance students={filteredStudents} attendanceRecords={attendanceRecords} setAttendanceRecords={setAttendanceRecords} isA={isA} discipline={discipline} />)}
        {active === 'events' && <Events events={filteredEvents} eventType={eventType} setEventType={setEventType} canManage={canManage} setShowEventForm={setShowEventForm} discipline={discipline} />}
        {active === 'fees' && !restrictedSenpai && <Fees students={filteredStudents} session={session} records={feeRecords} setRecords={setFeeRecords} isA={isA} />}
        {active === 'grading' && !restrictedSenpai && <Grading students={filteredStudents} session={session} records={gradingRecords} setRecords={setGradingRecords} canManage={canManage} />}
        {active === 'announcements' && <Announcements session={session} items={announcements} setItems={setAnnouncements} canManage={canManageEverything} dojos={dojos} />}
        {active === 'surveys' && <TournamentSurveys session={session} students={students} surveys={surveys} setSurveys={setSurveys} canManage={canManageEverything} /> }
        {active === 'reports' && (isA || isSensei) && <Reports students={students} events={events} attendanceRecords={attendanceRecords} fees={feeRecords} grading={gradingRecords} isA={isA} />}
        {active === 'dojos' && <Dojos isA={isA} canManage={canManage} discipline={discipline} dojos={dojos} setDojos={setDojos} />}
         {active === 'control' && canManageEverything && <Control isA={isA} isB={isB} students={students} ids={userAccounts} onCreateAccount={createAccount} onUpdateAccount={updateAccount} onDeleteAccount={deleteAccount} />}
      </div>
    </main>
    {showStudentForm && <Modal title="Add student / member profile" close={() => setShowStudentForm(false)}><form className="form-grid" onSubmit={addStudent}><label>Member name<input required value={newStudent.name} onChange={e=>setNewStudent({...newStudent,name:e.target.value})} placeholder="Full name"/></label><label>Member login ID<input required value={newStudent.id} onChange={e=>setNewStudent({...newStudent,id:e.target.value.toUpperCase()})} placeholder="WW-1005"/></label><label>Dojo<select value={newStudent.dojo} onChange={e=>setNewStudent({...newStudent,dojo:e.target.value})}><option value="">No dojo assigned</option>{dojos.map(d=><option key={d.id||d.name} value={d.name}>{d.name}</option>)}</select></label><label>Training discipline<select value={newStudent.style} disabled={newStudent.role==='Sensei'} onChange={e=>setNewStudent({...newStudent,style:e.target.value,eventId:''})}>{(newStudent.role==='Sensei'?['All']:['Karate','Kick boxing']).map(d=><option key={d}>{d}</option>)}</select></label><label>Assigned event<select value={newStudent.eventId} onChange={e=>setNewStudent({...newStudent,eventId:e.target.value})}><option value="">No event assigned</option>{events.filter(ev=>newStudent.style==='All'||ev.type===newStudent.style).map(ev=><option key={ev.id} value={ev.id}>{ev.title} · {ev.date}</option>)}</select></label><label>Current belt / level<select value={newStudent.belt} onChange={e=>setNewStudent({...newStudent,belt:e.target.value})}>{['White Belt','Yellow Belt','Orange Belt','Green Belt','Blue Belt','Purple Belt','Brown Belt','Black Belt'].map(x=><option key={x}>{x}</option>)}</select></label><label>Member type<select value={newStudent.role} onChange={e=>setNewStudent({...newStudent,role:e.target.value,style:e.target.value==='Sensei'?'All':(newStudent.style==='All'?'Karate':newStudent.style),eventId:''})}><option>Student</option><option>Senpai</option><option>Sensei</option></select></label><div className="form-actions"><button type="button" className="btn secondary" onClick={()=>setShowStudentForm(false)}>Cancel</button><button className="btn primary"><Plus size={16}/> Add profile</button></div></form></Modal>}
    {showEventForm && <Modal title="Create association event" close={() => setShowEventForm(false)}><form className="form-grid" onSubmit={addEvent}><label>Event name<input required value={newEvent.title} onChange={e=>setNewEvent({...newEvent,title:e.target.value})} placeholder="Training session"/></label><label>Event type<select value={newEvent.type} onChange={e=>setNewEvent({...newEvent,type:e.target.value})}><option>Karate</option><option>Kick boxing</option></select></label><label>Date<input type="date" required value={newEvent.date} onChange={e=>setNewEvent({...newEvent,date:e.target.value})}/></label><label>Time<input value={newEvent.time} onChange={e=>setNewEvent({...newEvent,time:e.target.value})} placeholder="07:00 AM"/></label><label>Dojo / venue<input value={newEvent.place} onChange={e=>setNewEvent({...newEvent,place:e.target.value})}/></label><div className="form-actions"><button type="button" className="btn secondary" onClick={()=>setShowEventForm(false)}>Cancel</button><button className="btn primary"><Plus size={16}/> Create event</button></div></form></Modal>}
  </div>
}

function Login({login,loginId,setLoginId,passcode,setPasscode,previewRole,setPreviewRole,loginMode,setLoginMode,notice,rememberMe,setRememberMe}) {
  return <div className="login-screen"><div className="login-visual"><div className="login-top-brand"><img src="/logo.png" alt="WWMAA crest"/><div><b>WORLD WIDE</b><span>MARTIAL ARTS ASSOCIATION</span></div></div><div className="hero-copy"><div className="eyebrow"><span/> DISCIPLINE · RESPECT · COURAGE</div><h1>FORGED BY<br/><em>DISCIPLINE.</em></h1><p>ONE ASSOCIATION. ONE SPIRIT. A LIFETIME OF MASTERY.</p><div className="hero-stats"><div><b>1983</b><span>Since</span></div><i/><div><b>01</b><span>Association</span></div><i/><div><b>∞</b><span>Possibilities</span></div></div></div><div className="brush-mark">武 道</div><div className="login-footer">WORLD WIDE MARTIAL ARTS ASSOCIATION <span>•</span> BUILT ON DISCIPLINE</div></div><div className="login-panel"><div className="mobile-crest"><img src="/logo.png" alt="WWMAA crest"/></div><div className="login-card"><div className="login-heading"><div className="mini-icon"><KeyRound size={20}/></div><div className="eyebrow">{loginMode === 'student' ? 'STUDENT & INSTRUCTOR ACCESS' : 'ADMINISTRATOR ACCESS'}</div><h2>{loginMode === 'student' ? 'Welcome, warrior.' : 'Welcome back.'}</h2><p>{loginMode === 'student' ? 'Sign in to view your profile, training and events.' : 'Sign in to manage the association portal.'}</p></div>
    <div className="login-mode-tabs"><button type="button" className={loginMode==='student'?'selected':''} onClick={()=>{setLoginMode('student');setNotice('')}}><Users size={15}/> Student / Senpai / Sensei</button><button type="button" className={loginMode==='admin'?'selected':''} onClick={()=>{setLoginMode('admin');setNotice('')}}><Shield size={15}/> Admin login</button></div>
    <form onSubmit={login}><label className="field-label">STUDENT / SENPAI / SENSEI ID<div className="input-wrap"><UserRound size={18}/><input autoComplete="username" value={loginId} onChange={e=>setLoginId(e.target.value)} placeholder="Enter your association ID" required/></div></label><label className="field-label">PASSCODE<div className="input-wrap"><KeyRound size={18}/><input autoComplete="current-password" type="password" value={passcode} onChange={e=>setPasscode(e.target.value)} placeholder="Enter passcode" required/></div></label> {loginMode === 'admin' && <label className="field-label">ADMIN ACCESS LEVEL<select className="role-select" value={previewRole} onChange={e=>setPreviewRole(e.target.value)}><option>A Level</option><option>B Level</option></select></label>}<label className="remember-device"><input type="checkbox" checked={rememberMe} onChange={e=>setRememberMe(e.target.checked)}/><span><b>Remember me on this device</b><small>Stay signed in when you reopen this website on this browser.</small></span></label><button className="btn primary login-submit">Enter member portal <ChevronRight size={18}/></button>{notice && <div className="error-msg">{notice}</div>}</form><div className="login-note"><Shield size={15}/><span>{loginMode === 'student' ? 'Student, Senpai and Sensei accounts use the separate member sign-in.' : 'Administrator accounts only. A and B levels can manage association accounts and passwords.'}</span></div><div className="demo-warning">V13 PREVIEW · DISCIPLINE-AWARE ASSOCIATION SUITE</div></div><div className="panel-bottom">© World Wide Martial Arts Association <span>•</span> Since 1983</div></div></div>
}

function PageTitle({eyebrow,title,description,action}) { return <div className="page-title-row"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action}</div> }
function Overview({role,students,events,setActive}) {
  return <><PageTitle eyebrow="ASSOCIATION OVERVIEW" title="The warrior's hub." description="Every dojo connected. Every session counted. Every member moving forward." action={<div className="today-chip"><CalendarDays size={16}/> {new Date().toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</div>}/>
    <div className="welcome-banner"><div className="banner-text"><span className="banner-kicker">WORLD WIDE MARTIAL ARTS ASSOCIATION</span><h2>ONE TEAM.<br/><em>NO LIMITS.</em></h2><p>Respect the art. Defend the team. Earn every next level.</p><button className="btn light" onClick={()=>setActive('events')}>Explore upcoming events <ChevronRight size={16}/></button></div><div className="banner-symbol">武</div><div className="banner-lines"/></div>
    <div className="stats-grid"><Stat icon={Users} label="Registered members" value={students.length.toString().padStart(2,'0')} note="Association directory" /><Stat icon={CalendarDays} label="Upcoming events" value={events.length.toString().padStart(2,'0')} note="Karate & kick boxing" /><Stat icon={MapPin} label="Active dojos" value={String(dojos.length).padStart(2,'0')} note="Training locations" /><Stat icon={Trophy} label="Your access" value={role==='A Level'?'A':role==='B Level'?'B':'MEMBER'} note={role==='A Level'?'Full control':'Member workspace'} /></div>
    <div className="section-heading"><div><h2>Coming up</h2><p>Upcoming association activities</p></div><button className="text-btn" onClick={()=>setActive('events')}>View all <ChevronRight size={15}/></button></div><div className="event-grid">{events.slice(0,3).map(e=><EventCard key={e.id} event={e}/>)}</div>
    <div className="fight-strip"><div className="fight-mark">WW<span>MAA</span></div><div><small>THE ASSOCIATION CODE</small><h2>RESPECT THE ROOTS. <em>OWN THE FUTURE.</em></h2><p>Karate spirit · Kick boxing power · One association family</p></div><span className="fight-kanji">武道</span></div><div className="section-heading"><div><h2>Association values</h2><p>The foundation of every practice</p></div></div><div className="values-grid"><Value n="01" title="Respect" text="Honor your instructors, teammates and the art."/><Value n="02" title="Discipline" text="Consistency builds confidence and capability."/><Value n="03" title="Courage" text="Grow through challenge, together as one team."/></div>
  </>
}
function Stat({icon:Icon,label,value,note}) {return <div className="stat-card"><div className="stat-top"><span className="stat-icon"><Icon size={18}/></span><span className="stat-mark">↗</span></div><div className="stat-value">{value}</div><div className="stat-label">{label}</div><div className="stat-note">{note}</div></div>}
function EventCard({event}) {return <article className="event-card"><div className={`event-type ${event.type==='Karate'?'karate':'kick'}`}><Swords size={15}/>{event.type}</div><h3>{event.title}</h3><div className="event-meta"><span><CalendarDays size={15}/>{event.date}</span><span><Clock3 size={15}/>{event.time||'Time to be announced'}</span><span><MapPin size={15}/>{event.place}</span></div><div className="event-card-bottom"><span className="event-status"><i/>{event.status}</span><span className="round-arrow"><ChevronRight size={17}/></span></div></article>}
function Value({n,title,text}) {return <div className="value-card"><span>{n}</span><div><h3>{title}</h3><p>{text}</p></div><div className="value-line"/></div>}
function Students({students,query,setQuery,canManage,isA,setShowStudentForm}) {return <><PageTitle eyebrow="MEMBER DIRECTORY" title="Student details." description="Association member profiles, dojo assignments and current belt levels." action={canManage&&<button className="btn primary" onClick={()=>setShowStudentForm(true)}><Plus size={16}/> Add student</button>}/><div className="panel"><div className="panel-toolbar"><div><h2>Member directory</h2><p>{students.length} profiles shown</p></div><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search name, ID, dojo..."/></div></div><div className="table-wrap"><table><thead><tr><th>MEMBER</th><th>ASSOCIATION ID</th><th>DOJO</th><th>CURRENT BELT</th><th>TYPE</th>{isA&&<th>ACCESS</th>}</tr></thead><tbody>{students.map(s=><tr key={s.id}><td><div className="member-cell"><span className="member-avatar">{s.name.split(' ').map(x=>x[0]).join('').replace('.','').slice(0,2)}</span><b>{s.name}</b></div></td><td><span className="id-chip">{s.id}</span></td><td>{s.dojo}</td><td><span className="belt-chip">{s.belt}</span></td><td>{s.role}</td>{isA&&<td><span className="access-chip">{s.role==='Sensi'?'B Level':'Member'}</span></td>}</tr>)}</tbody></table>{students.length===0&&<div className="empty-state">No profiles match your search.</div>}</div><div className="table-foot"><Shield size={15}/>{canManage?'B Level can add and view IDs. A Level controls permissions.':'Your profile directory is read-only.'}</div></div></>}

function StudentProfile({session,students,events}) {
  const member = students.find(s => s.id.toLowerCase() === session.id.toLowerCase()) || {id:session.id,name:'Association Member',dojo:'Assigned dojo',belt:'To be updated',role:session.role,style:'Karate'}
  return <><PageTitle eyebrow="MY MEMBER SPACE" title="Your training profile." description="Your personal association information and upcoming training."/><div className="student-profile-hero"><div className="student-profile-avatar">{member.name.split(' ').map(x=>x[0]).join('').replace('.','').slice(0,2)}</div><div><span className="eyebrow">WWMAA MEMBER</span><h2>{member.name}</h2><p>{member.id} · {member.role}</p></div><span className="belt-chip">{member.belt}</span></div><div className="stats-grid"><Stat icon={MapPin} label="Assigned dojo" value={member.dojo.includes(' ') ? member.dojo.split(' ')[0] : member.dojo} note={member.dojo}/><Stat icon={Swords} label="Discipline" value={member.style||'Karate'} note="Association training"/><Stat icon={CalendarDays} label="Upcoming events" value={events.length.toString().padStart(2,'0')} note="See event calendar"/><Stat icon={Shield} label="Member ID" value={member.id} note="Your association identity"/></div><div className="section-heading"><div><h2>Upcoming training</h2><p>Events listed by your association</p></div></div><div className="event-grid">{events.filter(e=>!member.eventId||String(e.id)===String(member.eventId)).slice(0,3).map(e=><EventCard key={e.id} event={e}/>)}</div></>
}
function StudentAttendance({session,students,attendanceRecords}) {
  const member = students.find(s => s.id.toLowerCase() === session.id.toLowerCase())
  const dojo = member?.dojo || ''
  const rows = attendanceRecords.filter(r => r.statuses?.[session.id] && (!dojo || r.dojo === dojo)).sort((a,b)=>b.date.localeCompare(a.date))
  const present = rows.filter(r=>r.statuses[session.id]==='Present').length
  return <><PageTitle eyebrow="MY TRAINING" title="Attendance record." description="Your recorded attendance by dojo and training date."/><div className="stats-grid"><Stat icon={ClipboardCheck} label="Sessions recorded" value={rows.length.toString().padStart(2,'0')} note={dojo||'Assigned dojo'}/><Stat icon={Check} label="Present" value={present.toString().padStart(2,'0')} note="Recorded sessions"/><Stat icon={MapPin} label="Assigned dojo" value={dojo||'—'} note="Attendance is dojo-based"/></div><div className="panel"><div className="panel-toolbar"><div><h2>My attendance history</h2><p>Member ID: {session.id} · {dojo||'Dojo not assigned'}</p></div><span className="demo-tag">SHARED RECORDS</span></div><div className="table-wrap"><table><thead><tr><th>DATE</th><th>DOJO</th><th>DISCIPLINE</th><th>STATUS</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{r.date}</td><td>{r.dojo}</td><td>{r.discipline}</td><td><span className={`attendance-status ${r.statuses[session.id].toLowerCase()}`}>{r.statuses[session.id]}</span></td></tr>)}</tbody></table>{!rows.length&&<div className="empty-state"><ClipboardCheck size={25}/><p>No attendance records have been saved for your account yet.</p></div>}</div></div></>
}

function Attendance({students,attendanceRecords,setAttendanceRecords,isA,discipline='All'}) {
  const today = new Date().toISOString().slice(0,10)
  const [dojo,setDojo] = useState('')
  const [date,setDate] = useState(today)
  const [trainingDiscipline,setTrainingDiscipline] = useState(discipline==='All'?'Karate':discipline)
  const [marked,setMarked] = useState({})
  const [message,setMessage] = useState('')
  const dojos = [...new Set(students.map(s=>s.dojo).filter(Boolean))]
  const dojoStudents = students.filter(s=>s.dojo===dojo && (s.style || 'Karate').toLowerCase()===trainingDiscipline.toLowerCase())
  const current = attendanceRecords.find(r=>r.date===date && r.dojo===dojo && r.discipline===trainingDiscipline)
  React.useEffect(()=>{setMarked(current?.statuses || {});setMessage('')},[date,dojo,trainingDiscipline,attendanceRecords])
  const history = attendanceRecords.filter(r=>r.dojo===dojo).sort((a,b)=>b.date.localeCompare(a.date))
  function saveSession(){
    const record={id:current?.id || `${dojo}-${date}-${trainingDiscipline}`.replace(/\s+/g,'-'),date,dojo,discipline:trainingDiscipline,statuses:marked,updatedAt:new Date().toISOString()}
    const next=[...attendanceRecords.filter(r=>!(r.date===date && r.dojo===dojo && r.discipline===trainingDiscipline)),record].sort((a,b)=>b.date.localeCompare(a.date))
    setAttendanceRecords(next);localStorage.setItem('wwmaa-attendance-v10',JSON.stringify(next));setMessage(`Attendance saved for ${dojo} on ${date}. You can select an earlier date above to correct a previous session.`)
  }
  function deleteRecord(record){if(!isA)return;const next=attendanceRecords.filter(r=>r.id!==record.id);setAttendanceRecords(next);localStorage.setItem('wwmaa-attendance-v10',JSON.stringify(next));setMessage(`Attendance record for ${record.date} deleted.`)}
  return <><PageTitle eyebrow="TRAINING RECORDS" title="Dojo attendance." description="Record attendance separately for each dojo, date and discipline. Select a past date to correct an earlier record." action={<div className="today-chip"><CalendarDays size={16}/>{new Date().toLocaleDateString('en-IN',{day:'2-digit',month:'short'})}</div>}/>
    <div className="panel attendance-editor"><div className="panel-toolbar"><div><h2>Session setup</h2><p>Choose the dojo and date before marking the roll call.</p></div><span className="demo-tag">SHARED DATA</span></div><div className="attendance-filters"><label>Dojo<select value={dojo} onChange={e=>setDojo(e.target.value)}><option value="">Select dojo</option>{dojos.map(d=><option key={d}>{d}</option>)}</select></label><label>Training date <input type="date" value={date} onChange={e=>setDate(e.target.value)} max="2099-12-31"/></label><label>Discipline<select value={trainingDiscipline} onChange={e=>setTrainingDiscipline(e.target.value)}>{(discipline==='All'?['Karate','Kick boxing']:[discipline]).map(d=><option key={d}>{d}</option>)}</select></label></div><div className="attendance-banner"><ClipboardCheck size={24}/><div><b>{dojo} · {trainingDiscipline}</b><p>{date===today?'Today’s session':`Session date: ${date}`}{current?' · Existing record loaded for editing':' · New session'}</p></div><span>{Object.values(marked).filter(v=>v==='Present').length}/{dojoStudents.length} present</span></div>
    <div className="panel-toolbar attendance-roll-heading"><div><h2>Member roll call</h2><p>{dojoStudents.length} members assigned to this dojo. Use the status buttons to update each person.</p></div></div><div className="attendance-list">{dojoStudents.map(s=>{const status=marked[s.id]||'Unmarked';return <div className="attendance-row" key={s.id}><div className="member-cell"><span className="member-avatar">{s.name.split(' ').map(x=>x[0]).join('').replace('.','').slice(0,2)}</span><div><b>{s.name}</b><small>{s.id} · {s.belt}</small></div></div><div className="attendance-status-actions">{['Present','Absent','Late'].map(v=><button key={v} className={`attendance-status-btn ${status===v?'selected '+v.toLowerCase():''}`} onClick={()=>setMarked(prev=>({...prev,[s.id]:v}))}>{v}</button>)}</div></div>})}{dojoStudents.length===0&&<div className="empty-state">No member profiles are assigned to this dojo yet.</div>}</div><div className="attendance-save-row"><span>{current?'Editing a saved record':'Creating a new attendance record'}{date!==today?' · Past-date correction enabled':''}</span><button className="btn primary" onClick={saveSession}><Check size={16}/> Save attendance</button></div></div>
    {message&&<div className="notice"><Check size={16}/>{message}<button onClick={()=>setMessage('')}><X size={15}/></button></div>}
    <div className="panel"><div className="panel-toolbar"><div><h2>Previous attendance records</h2><p>History for {dojo}. Click Edit to load a saved date and adjust statuses.</p></div><span className="demo-tag">{history.length} RECORDS</span></div><div className="table-wrap"><table><thead><tr><th>DATE</th><th>DOJO</th><th>DISCIPLINE</th><th>PRESENT</th><th>ABSENT</th><th>LATE</th><th>ACTION</th></tr></thead><tbody>{history.map(r=><tr key={r.id}><td>{r.date}</td><td>{r.dojo}</td><td>{r.discipline}</td><td>{Object.values(r.statuses||{}).filter(v=>v==='Present').length}</td><td>{Object.values(r.statuses||{}).filter(v=>v==='Absent').length}</td><td>{Object.values(r.statuses||{}).filter(v=>v==='Late').length}</td><td><button className="text-btn" onClick={()=>{setDate(r.date);setTrainingDiscipline(r.discipline);setDojo(r.dojo);setMarked(r.statuses||{});setMessage('Past record loaded. Make corrections and save attendance.')}}><Pencil size={13}/> Edit</button>{isA&&<button className="text-btn muted" onClick={()=>deleteRecord(r)}>Delete</button>}</td></tr>)}</tbody></table>{!history.length&&<div className="empty-state">No previous sessions recorded for this dojo.</div>}</div></div>
  </>
}
function Events({events,eventType,setEventType,canManage,setShowEventForm,discipline='All'}) {const eventOptions=discipline==='All'?['All','Karate','Kick boxing']:[discipline];return <><PageTitle eyebrow="ASSOCIATION CALENDAR" title="Events & training." description="Separate event settings for Karate and Kick boxing." action={canManage&&<button className="btn primary" onClick={()=>setShowEventForm(true)}><Plus size={16}/> New event</button>}/><div className="event-controls"><div className="segmented">{eventOptions.map(t=><button key={t} className={eventType===t?'selected':''} onClick={()=>setEventType(t)}>{t==='All'?'All events':t}</button>)}</div><div className="event-settings-note"><Settings size={16}/><span>Each event has its own discipline and settings.</span></div></div><div className="event-grid large">{events.map(e=><EventCard key={e.id} event={e}/>)}</div>{events.length===0&&<div className="empty-state panel">No events in this category yet.</div>}</>}
function Dojos({isA,canManage,discipline='All',dojos,setDojos}) {
 const [show,setShow]=useState(false); const [selectedDiscipline,setSelectedDiscipline]=useState(discipline==='All'?'Karate':discipline);
 const [draft,setDraft]=useState({name:'',place:'',lead:'',classTimes:'',disciplines:['Karate']});
 const visibleDojos=dojos.filter(d=>(d.disciplines||['Karate','Kick boxing']).includes(selectedDiscipline));
 const disciplineOptions=discipline==='All'?['Karate','Kick boxing']:[discipline];
 function saveDojo(e){e.preventDefault();if(!draft.name.trim())return;const next=[...dojos,{...draft,id:Date.now(),disciplines:draft.disciplines.length?draft.disciplines:[selectedDiscipline]}];setDojos(next);localStorage.setItem('wwmaa-dojos-v10',JSON.stringify(next));setDraft({name:'',place:'',lead:'',classTimes:'',disciplines:[selectedDiscipline]});setShow(false)}
 return <><PageTitle eyebrow="DOJO & CLASS MANAGEMENT" title="Our dojos." description="Manage dojo locations, training disciplines, instructors and weekly class times." action={isA&&<button className="btn primary" onClick={()=>setShow(v=>!v)}><Plus size={16}/> New dojo</button>}/>
 {show&&isA&&<form className="panel form-grid feature-form" onSubmit={saveDojo}><label>Dojo name<input required value={draft.name} onChange={e=>setDraft({...draft,name:e.target.value})} placeholder="e.g. Westside Dojo"/></label><label>Location<input required value={draft.place} onChange={e=>setDraft({...draft,place:e.target.value})} placeholder="Town / address"/></label><label>Instructor / lead<input value={draft.lead} onChange={e=>setDraft({...draft,lead:e.target.value})} placeholder="Sensei name"/></label><label>Weekly class times<input required value={draft.classTimes} onChange={e=>setDraft({...draft,classTimes:e.target.value})} placeholder="Sat 6–8 AM · Sun 4–6 PM"/></label><fieldset className="wide-field discipline-field"><legend>Disciplines available</legend>{['Karate','Kick boxing'].map(d=><label className="check-label" key={d}><input type="checkbox" checked={draft.disciplines.includes(d)} onChange={e=>setDraft({...draft,disciplines:e.target.checked?[...draft.disciplines,d]:draft.disciplines.filter(x=>x!==d)})}/>{d}</label>)}</fieldset><div className="form-actions"><button type="button" className="btn secondary" onClick={()=>setShow(false)}>Cancel</button><button className="btn primary"><Plus size={16}/> Save dojo</button></div></form>}
 <div className="event-controls"><div className="segmented">{disciplineOptions.map(t=><button type="button" key={t} className={selectedDiscipline===t?'selected':''} onClick={()=>setSelectedDiscipline(t)}>{t}</button>)}</div><span className="event-settings-note">Showing {selectedDiscipline} dojos</span></div>
 <div className="dojo-grid">{visibleDojos.map((d,i)=><article className="dojo-card" key={d.id||d.name}><div className="dojo-card-top"><div className="dojo-icon"><Building2 size={22}/></div><span className="dojo-number">DOJO / {String(i+1).padStart(2,'0')}</span></div><h2>{d.name}</h2><p><MapPin size={15}/>{d.place}</p><div className="dojo-details"><div><small>INSTRUCTOR</small><b>{d.lead||'To be assigned'}</b></div><div><small>DISCIPLINES</small><b>{(d.disciplines||[]).join(' · ')}</b></div></div><div className="dojo-schedule"><Clock3 size={16}/><div><small>CLASS SCHEDULE</small><p>{d.classTimes||'Class time not set yet'}</p></div></div><div className="dojo-foot"><span><i/> Active dojo</span>{isA&&<div className="dojo-admin-actions"><button type="button" className="text-button" onClick={()=>{const value=window.prompt('Edit weekly class times',d.classTimes||'');if(value!==null){const next=dojos.map(x=>(x.id||x.name)===(d.id||d.name)?{...x,classTimes:value}:x);setDojos(next);localStorage.setItem('wwmaa-dojos-v10',JSON.stringify(next))}}}>Edit schedule</button><button type="button" className="text-button dojo-delete-button" onClick={()=>{if(!window.confirm(`Delete dojo “${d.name}”? This will remove it from the dojo list.`))return;const next=dojos.filter(x=>(x.id||x.name)!==(d.id||d.name));setDojos(next);localStorage.setItem('wwmaa-dojos-v10',JSON.stringify(next))}}>Delete dojo</button></div>}</div></article>)}</div>
 {!visibleDojos.length&&<div className="empty-state panel">No dojos have {selectedDiscipline} listed yet.</div>}
 <div className="feature-note"><Megaphone size={16}/> Association notices can target a specific dojo from the Announcements page.</div></>
}
function Control({isA,isB,students,ids,onCreateAccount,onUpdateAccount,onDeleteAccount}) {
  const [searchId, setSearchId] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)
  const [saved, setSaved] = useState('')
  const [form, setForm] = useState({id:'',name:'',role:'Student',dojo:'',belt:'White Belt',style:'Karate',password:''})
  const shownIds = ids.filter(x => (x.id+' '+x.name+' '+x.role).toLowerCase().includes(searchId.toLowerCase()))
  const disciplineOptions = ['Sensei','Sensi','A Level','B Level'].includes(form.role) ? ['All'] : ['Karate','Kick boxing']
  const canEdit = (account) => isA || (isB && account.role === 'Senpai')
  function beginEdit(account) {
    if (!canEdit(account)) return
    setEditing(account.id)
    setForm({...account, password:''})
  }
  async function saveAccount(e) {
    e.preventDefault()
    if (!form.id.trim() || !form.name.trim()) return
    if (editing) {
      const target = ids.find(x => x.id === editing)
      if (!target || !canEdit(target)) return
      if (ids.some(x => x.id.toLowerCase() === form.id.trim().toLowerCase() && x.id !== editing)) {
        setSaved('That login ID already exists.'); return
      }
      try {
        await onUpdateAccount(editing, { id: form.id.trim().toUpperCase(), name: form.name.trim(), role: form.role, dojo: form.dojo || '', belt: form.belt || '', style: form.style || 'Karate', password: form.password || undefined })
        setSaved(form.password ? 'Account details and password updated for all devices.' : 'Account details updated for all devices.')
      } catch (error) { setSaved(error.message || 'Could not update account.'); return }
    } else {
      if (!isA) return
      if (!form.password || form.password.length < 8) { setSaved('Set a password with at least 8 characters.'); return }
      if (ids.some(x => x.id.toLowerCase() === form.id.trim().toLowerCase())) { setSaved('That login ID already exists.'); return }
      try {
        await onCreateAccount({ id: form.id.trim().toUpperCase(), name: form.name.trim(), role: form.role, dojo: form.dojo || '', belt: form.belt || '', style: form.style || 'Karate', password: form.password })
        setSaved('Account created securely. The member can now sign in from another device.')
      } catch (error) { setSaved(error.message || 'Could not create account.'); return }
    }
    setEditing(null); setShowForm(false)
    setForm({id:'',name:'',role:'Student',dojo:'',belt:'White Belt',style:'Karate',password:''})
  }
  async function removeAccount(account) {
    if (!isA || account.role === 'A Level' && account.id === 'WWMAA-ADMIN-001') return
    try { await onDeleteAccount(account.id); setSaved('Account deleted from the shared database.') }
    catch (error) { setSaved(error.message || 'Could not delete account.') }
  }
  return <>
    <PageTitle eyebrow="ADMINISTRATION" title="User control panel." description={isA ? 'A Level can manage every user and administrator account, IDs, roles and password resets.' : 'B Level access is limited to editing Senpai accounts only.'} />
    <div className="control-alert"><Shield size={20}/><div><b>{isA?'A Level · Full user control':'B Level · Senpai-only editing'}</b><p>{isA?'Edit all member and admin details, create accounts, change login IDs and roles, and set a new password when required. Set a separate password for each account; existing passwords are never shown.':'You can edit Senpai account details only. Other members and administrator accounts are read-only. You cannot create admin accounts or change roles.'}</p></div></div>
    {saved && <div className="notice"><Check size={16}/>{saved}<button onClick={()=>setSaved('')}><X size={15}/></button></div>}
    <div className="panel control-section">
      <div className="panel-toolbar"><div><h2>All user accounts</h2><p>{shownIds.length} accounts · accounts stored centrally in WWMAA Supabase</p></div>{isA&&<button className="btn primary" onClick={()=>{setEditing(null);setForm({id:'',name:'',role:'Student',dojo:'',belt:'White Belt',style:'Karate',password:''});setShowForm(!showForm)}}><Plus size={16}/>{showForm?'Close form':'Create account'}</button>}</div>
      {(showForm || editing) && <form className="form-grid control-form" onSubmit={saveAccount}>
        <label>Login ID<input required value={form.id} onChange={e=>setForm({...form,id:e.target.value})} placeholder="WW-1005" disabled={!!editing && isB}/></label>
        <label>Full name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Full name"/></label>
        <label>Role<select value={form.role} disabled={isB} onChange={e=>setForm({...form,role:e.target.value,style:['Sensei','A Level','B Level'].includes(e.target.value)?'All':(['Karate','Kick boxing'].includes(form.style)?form.style:'Karate')})}>{['Student','Senpai','Sensei','B Level','A Level'].map(r=><option key={r}>{r}</option>)}</select></label>
        <label>Dojo<input value={form.dojo||''} onChange={e=>setForm({...form,dojo:e.target.value})}/></label>
        <label>Belt<input value={form.belt||''} onChange={e=>setForm({...form,belt:e.target.value})}/></label>
        <label>Discipline<select value={form.style||'Karate'} onChange={e=>setForm({...form,style:e.target.value})}>{disciplineOptions.map(d=><option key={d}>{d}</option>)}</select></label>
        {isA && <label>{editing?'Set new password (optional)':'Initial password'}<input type="password" value={form.password||''} onChange={e=>setForm({...form,password:e.target.value})} placeholder={editing?'Leave blank to keep unchanged':'Set initial password'} autoComplete="new-password"/></label>}
        <div className="form-actions"><button type="button" className="btn secondary" onClick={()=>{setEditing(null);setShowForm(false)}}>Cancel</button><button className="btn primary"><Check size={16}/>{editing?'Save account':'Create account'}</button></div>
      </form>}
      <div className="panel-toolbar id-search-toolbar"><div className="search-box"><Search size={17}/><input value={searchId} onChange={e=>setSearchId(e.target.value)} placeholder="Search name, ID, role..."/></div><span className="demo-tag">SHARED ACCOUNTS</span></div>
      <div className="table-wrap"><table><thead><tr><th>NAME</th><th>LOGIN ID</th><th>ROLE</th><th>DOJO</th><th>BELT</th><th>PASSWORD</th><th>ACTIONS</th></tr></thead><tbody>{shownIds.map(x=><tr key={x.id}><td>{x.name}</td><td><span className="id-chip">{x.id}</span></td><td><span className="access-chip">{x.role}</span></td><td>{x.dojo||'—'}</td><td>{x.belt||'—'}</td><td><span className="access-chip">{x.passwordSet?'Set':'Not set'}</span></td><td>{canEdit(x)?<div className="row-actions"><button className="text-btn" onClick={()=>beginEdit(x)}><Pencil size={13}/> Edit</button>{isA&&<button className="text-btn muted" onClick={()=>removeAccount(x)}>Delete</button>}</div>:<span className="muted">View only</span>}</td></tr>)}</tbody></table>{shownIds.length===0&&<div className="empty-state">No accounts match your search.</div>}</div>
    </div>
    <div className="panel security-panel"><div className="security-icon"><KeyRound size={20}/></div><div><h3>Password management</h3><p>A Level can set a new password for any account, but cannot view an existing password. B Level can edit Senpai details only and has no password-management controls in this preview. Passwords are managed by Supabase Auth and are never shown in this panel.</p></div></div>
    <div className="panel security-panel"><div className="security-icon"><CircleHelp size={20}/></div><div><h3>How to edit users easily</h3><p>Accounts are managed through the secure WWMAA backend. New IDs and password changes are stored in Supabase, so members can sign in from other phones after the changes are saved.</p></div></div>
  </>
}

function Fees({students,session,records,setRecords,isA}) {
  const [member,setMember]=useState(session.loginMode==='student'?session.id:'')
  const [month,setMonth]=useState(new Date().toISOString().slice(0,7))
  const [amount,setAmount]=useState('750')
  const [note,setNote]=useState('Monthly training fee')
  const [filter,setFilter]=useState('All')
  const [sortBy,setSortBy]=useState('Status')
  const visible=records.filter(r => ((session.loginMode!=='student'||['Sensei','Sensi'].includes(session.role)) || r.memberId===session.id) && (filter==='All'||(filter==='Unpaid'&&['Due','Unpaid'].includes(r.status))||r.status===filter) && (month==='Any month'||r.month===month)).sort((a,b)=>sortBy==='Status'?(['Unpaid','Due','Paid','Waived'].indexOf(a.status)-['Unpaid','Due','Paid','Waived'].indexOf(b.status)):sortBy==='Name'?a.name.localeCompare(b.name):sortBy==='Amount'?Number(b.amount)-Number(a.amount):sortBy==='Month'?String(b.month).localeCompare(String(a.month)):a.name.localeCompare(b.name))
  function add(e){e.preventDefault();const who=students.find(s=>s.id===member)||{id:member,name:session.name,dojo:session.dojo||''};if(!who.id)return;const rec={id:Date.now(),memberId:who.id,name:who.name,dojo:who.dojo,month,amount:Number(amount),note,status:'Due',paidAt:'Not paid yet'};const next=[rec,...records];setRecords(next);localStorage.setItem('wwmaa-fees-v10',JSON.stringify(next))}
  function statusChange(id,status){const next=records.map(r=>r.id===id?{...r,status}:r);setRecords(next);localStorage.setItem('wwmaa-fees-v10',JSON.stringify(next))}
  return <><PageTitle eyebrow="MEMBERSHIP FINANCE" title="Fees & payments." description="Track monthly training fees, dues and payment history by member and dojo." action={<span className="today-chip"><Receipt size={16}/> ₹{visible.filter(r=>r.status==='Paid').reduce((a,r)=>a+r.amount,0).toLocaleString('en-IN')} collected</span>}/>
  {isA&&<form className="panel form-grid feature-form" onSubmit={add}><label>Member<select required value={member} onChange={e=>setMember(e.target.value)}><option value="">Select member</option>{students.map(s=><option value={s.id} key={s.id}>{s.name} · {s.id}</option>)}</select></label><label>Fee month<input type="month" value={month} onChange={e=>setMonth(e.target.value)} required/></label><label>Amount (₹)<input type="number" min="0" value={amount} onChange={e=>setAmount(e.target.value)} required/></label><label>Note<input value={note} onChange={e=>setNote(e.target.value)} placeholder="Monthly fee / registration"/></label><div className="form-actions"><button className="btn primary"><Plus size={16}/> Record payment</button></div></form>}
  <div className="panel"><div className="panel-toolbar"><div><h2>Payment ledger</h2><p>{session.loginMode==='student'?'Your payment records':'Recorded transactions · shared WWMAA database'}</p></div><div className="feature-controls"><select value={filter} onChange={e=>setFilter(e.target.value)}><option>All</option><option>Unpaid</option><option>Due</option><option>Paid</option><option>Waived</option></select><select value={sortBy} onChange={e=>setSortBy(e.target.value)} aria-label="Sort fee records"><option value="Status">Sort: Unpaid → Paid</option><option value="Name">Sort: Member name</option><option value="Amount">Sort: Amount</option><option value="Month">Sort: Month</option></select><select value={month} onChange={e=>setMonth(e.target.value)} aria-label="Filter fee month"><option value="Any month">Any month</option><option value={new Date().toISOString().slice(0,7)}>{new Date().toISOString().slice(0,7)}</option>{[...new Set(records.map(r=>r.month))].filter(m=>m!==new Date().toISOString().slice(0,7)).sort().reverse().map(m=><option key={m} value={m}>{m}</option>)}</select></div></div><div className="table-wrap"><table><thead><tr><th>MEMBER</th><th>DOJO</th><th>MONTH</th><th>AMOUNT</th><th>STATUS</th><th>DATE</th>{isA&&<th>ACTION</th>}</tr></thead><tbody>{visible.map(r=><tr key={r.id}><td>{r.name}<small className="table-sub">{r.memberId}</small></td><td>{r.dojo}</td><td>{r.month}</td><td>₹{Number(r.amount).toLocaleString('en-IN')}</td><td><span className={`payment-pill ${r.status.toLowerCase()}`}>{r.status}</span></td><td>{r.paidAt}</td>{isA&&<td><select className="table-select" value={r.status} onChange={e=>statusChange(r.id,e.target.value)}><option>Due</option><option>Unpaid</option><option>Paid</option><option>Waived</option></select></td>}</tr>)}</tbody></table>{!visible.length&&<div className="empty-state">No fee records match this filter yet. A Level can add the first payment above.</div>}</div></div><div className="feature-note"><Shield size={16}/> Manual fee ledger only: no online payment is collected through this website. A Level marks a fee Paid after receiving and verifying payment offline.</div></>
}
function Grading({students,session,records,setRecords,canManage}) {
 const [member,setMember]=useState('');const [belt,setBelt]=useState('Yellow Belt');const [date,setDate]=useState(new Date().toISOString().slice(0,10));const [result,setResult]=useState('Passed');const [notes,setNotes]=useState('');const belts=['White Belt','Yellow Belt','Orange Belt','Green Belt','Blue Belt','Purple Belt','Brown Belt','Black Belt'];
 const list=records.filter(r=>session.loginMode!=='student'||['Sensei','Sensi'].includes(session.role)||r.memberId===session.id).sort((a,b)=>b.date.localeCompare(a.date));
 function add(e){e.preventDefault();const s=students.find(x=>x.id===member);if(!s)return;const n=[{id:Date.now(),memberId:s.id,name:s.name,dojo:s.dojo,belt,date,result,notes},...records];setRecords(n);localStorage.setItem('wwmaa-grading-v10',JSON.stringify(n))}
 return <><PageTitle eyebrow="RANK & DEVELOPMENT" title="Belt progression." description="Keep a history of grading assessments, results, instructor feedback and the next milestone."/><div className="feature-highlight"><GraduationCap size={25}/><div><b>Progress is earned, not rushed.</b><p>Record each assessment and keep the association's belt history in one place.</p></div><span className="demo-tag">GRADING LOG</span></div>{canManage&&<form className="panel form-grid feature-form" onSubmit={add}><label>Member<select required value={member} onChange={e=>setMember(e.target.value)}><option value="">Select member</option>{students.map(s=><option key={s.id} value={s.id}>{s.name} · {s.id}</option>)}</select></label><label>Assessment date<input type="date" value={date} onChange={e=>setDate(e.target.value)} required/></label><label>Assessed belt<select value={belt} onChange={e=>setBelt(e.target.value)}>{belts.map(b=><option key={b}>{b}</option>)}</select></label><label>Result<select value={result} onChange={e=>setResult(e.target.value)}><option>Passed</option><option>Needs practice</option><option>Deferred</option></select></label><label className="wide-field">Instructor feedback<textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Strengths, areas to improve, next steps"/></label><div className="form-actions"><button className="btn primary"><Plus size={16}/> Save assessment</button></div></form>}<div className="panel"><div className="panel-toolbar"><div><h2>Assessment history</h2><p>{list.length} recorded assessments</p></div></div><div className="table-wrap"><table><thead><tr><th>DATE</th><th>MEMBER</th><th>DOJO</th><th>BELT</th><th>RESULT</th><th>INSTRUCTOR NOTES</th></tr></thead><tbody>{list.map(r=><tr key={r.id}><td>{r.date}</td><td>{r.name}<small className="table-sub">{r.memberId}</small></td><td>{r.dojo}</td><td><span className="belt-chip">{r.belt}</span></td><td>{r.result}</td><td>{r.notes||'—'}</td></tr>)}</tbody></table>{!list.length&&<div className="empty-state">No grading history yet.</div>}</div></div></>
}
function Announcements({session,items,setItems,canManage,dojos=[]}) {
 const [title,setTitle]=useState('');const [body,setBody]=useState('');const [audience,setAudience]=useState('All members');const [dojo,setDojo]=useState('All dojos');const [priority,setPriority]=useState('Normal');const [voiceRate,setVoiceRate]=useState('1');
 function speak(text){if(!('speechSynthesis' in window)){window.alert('Voice announcements are not supported in this browser. Try current Chrome or Edge.');return}window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='en-IN';u.rate=Number(voiceRate)||1;window.speechSynthesis.speak(u)}
 function publish(e){e.preventDefault();const next=[{id:Date.now(),title:title.trim(),body:body.trim(),audience,dojo,priority,date:new Date().toISOString().slice(0,10),author:session.name,authorRole:session.role},...items];setItems(next);localStorage.setItem('wwmaa-announcements-v10',JSON.stringify(next));setTitle('');setBody('')}
 const audienceMatches=(item)=>{const a=item.audience||'All members';const roleMatch=['Everyone','All members'].includes(a)|| (a==='Students'&&session.role==='Student')||(a==='Senpais'&&session.role==='Senpai')||(a==='Senseis'&&['Sensei','Sensi'].includes(session.role))||(a==='Administrators'&&['A Level','B Level'].includes(session.role))||a===session.role;const dojoMatch=!item.dojo||item.dojo==='All dojos'||item.dojo===session.dojo;return roleMatch&&dojoMatch};
 const visible=items.filter(audienceMatches).sort((a,b)=>b.date.localeCompare(a.date));
 return <><PageTitle eyebrow="OFFICIAL ASSOCIATION BULLETIN" title="Announcements." description="Publish role-specific and dojo-specific notices, with browser voice playback for members."/>
 {canManage&&<form className="panel form-grid feature-form" onSubmit={publish}><label>Announcement title<input required maxLength="120" value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Sunday training time update"/></label><label>Target audience<select value={audience} onChange={e=>setAudience(e.target.value)}><option>All members</option><option>Students</option><option>Senpais</option><option>Senseis</option><option>Administrators</option><option>A Level</option><option>B Level</option></select></label><label>Target dojo<select value={dojo} onChange={e=>setDojo(e.target.value)}><option>All dojos</option>{dojos.map(d=><option key={d.id||d.name}>{d.name}</option>)}</select></label><label>Priority<select value={priority} onChange={e=>setPriority(e.target.value)}><option>Normal</option><option>Important</option><option>Urgent</option></select></label><label className="wide-field">Message<textarea required maxLength="3000" rows="4" value={body} onChange={e=>setBody(e.target.value)} placeholder="Write the notice. Include class time, venue and what members need to do."/></label><div className="voice-preview wide-field"><div><b><Megaphone size={16}/> Voice announcement preview</b><small>Uses your browser's text-to-speech voice; this is not a live voice call.</small></div><select value={voiceRate} onChange={e=>setVoiceRate(e.target.value)} aria-label="Voice speed"><option value="0.85">Slow</option><option value="1">Normal</option><option value="1.15">Fast</option></select><button type="button" className="btn secondary" disabled={!title.trim()&&!body.trim()} onClick={()=>speak(`${title}. ${body}`)}><Bell size={16}/> Preview voice</button></div><div className="form-actions"><button className="btn primary"><Megaphone size={16}/> Publish notice</button></div></form>}
 <div className="announcement-list">{visible.map(x=><article className={`panel announcement-card announcement-${String(x.priority||'Normal').toLowerCase()}`} key={x.id}><div className="announcement-icon"><Megaphone size={20}/></div><div className="announcement-content"><div className="announcement-meta"><span>{x.date}</span><span>{x.audience||'All members'}</span><span>{x.dojo||'All dojos'}</span><span className="priority-chip">{x.priority||'Normal'}</span></div><h2>{x.title}</h2><p>{x.body}</p><small>{x.author?`Posted by ${x.author}`:'WWMAA Association'}{x.authorRole?` · ${x.authorRole}`:''}</small><div className="announcement-actions"><button className="btn secondary small-btn" onClick={()=>speak(`${x.title}. ${x.body}`)}><Megaphone size={15}/> Listen to announcement</button>{canManage&&<button className="btn secondary small-btn" onClick={()=>{const n=items.filter(a=>a.id!==x.id);setItems(n);localStorage.setItem('wwmaa-announcements-v10',JSON.stringify(n))}}>Delete</button>}</div></div></article>)}{!visible.length&&<div className="empty-state panel">No announcements targeted to your account or dojo yet.</div>}</div></>
}
function TournamentSurveys({session,students,surveys,setSurveys,canManage}) {
 const [title,setTitle]=useState('');
 const [description,setDescription]=useState('');
 const [eventName,setEventName]=useState('');
 const [deadline,setDeadline]=useState('');
 const [targetIds,setTargetIds]=useState([]);
 const [questionText,setQuestionText]=useState('');
 const [questionType,setQuestionType]=useState('Short answer');
 const [optionsText,setOptionsText]=useState('Yes,No');
 const [uppercaseNames,setUppercaseNames]=useState(true);
 const [activeSurveyId,setActiveSurveyId]=useState('');
 const [answers,setAnswers]=useState({});
 const [responseNotice,setResponseNotice]=useState('');
 const ownRole=session.role;
 const [responsesOpen,setResponsesOpen]=useState({});
 const saveAll=(next)=>{setSurveys(next);localStorage.setItem('wwmaa-surveys-v10',JSON.stringify(next))};
 const eligible=students.filter(s=>['Student','Senpai'].includes(s.role));
 const assignedSurvey=surveys.filter(s=>s.targetIds.includes(session.id));
 const activeSurvey=surveys.find(s=>String(s.id)===String(activeSurveyId));
 function addQuestion(){if(!questionText.trim())return;const q={id:Date.now()+Math.random(),text:questionText.trim(),type:questionType,options:questionType==='Multiple choice'||questionType==='Checkboxes'?optionsText.split(',').map(x=>x.trim()).filter(Boolean):[]};setDraftQuestions(prev=>[...prev,q]);setQuestionText('')}
 const [draftQuestions,setDraftQuestions]=useState([]);
 function createSurvey(e){e.preventDefault();if(!title.trim()||!targetIds.length||!draftQuestions.length)return;const item={id:Date.now(),title:title.trim(),description:description.trim(),eventName:eventName.trim(),deadline,targetIds:[...targetIds],questions:draftQuestions,responses:[],createdAt:new Date().toISOString(),createdBy:session.id,createdByRole:ownRole,uppercaseNames};saveAll([item,...surveys]);setTitle('');setDescription('');setEventName('');setDeadline('');setTargetIds([]);setDraftQuestions([]);setResponseNotice('Survey created. Only selected members can see and submit it.');}
 function submitResponse(e,survey){e.preventDefault();if(survey.deadline&&survey.deadline<new Date().toISOString().slice(0,10)){setResponseNotice('This survey is closed because the deadline has passed.');return}const already=survey.responses.some(r=>r.memberId===session.id);if(already){setResponseNotice('You have already submitted this survey.');return}const response={id:Date.now(),memberId:session.id,memberName:session.name||students.find(s=>s.id===session.id)?.name||session.id,submittedAt:new Date().toISOString(),answers:survey.questions.map(q=>({questionId:q.id,question:q.text,answer:Array.isArray(answers[q.id])?answers[q.id].join('; '):(answers[q.id]||'')}))};const next=surveys.map(s=>s.id===survey.id?{...s,responses:[...s.responses,response]}:s);saveAll(next);setAnswers({});setResponseNotice('Your tournament survey response has been submitted.');}
 function exportResponses(survey){const rows=[['Member ID','Member name','Submitted at',...survey.questions.map(q=>q.text)]];survey.responses.forEach(r=>{let name=String(r.memberName||'');if(survey.uppercaseNames)name=name.toLocaleUpperCase('en-IN');rows.push([r.memberId,name,new Date(r.submittedAt).toLocaleString('en-IN'),...survey.questions.map(q=>r.answers.find(a=>a.questionId===q.id)?.answer||'')])});const csv='\ufeff'+rows.map(row=>row.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`wwmaa-survey-${survey.title.replace(/[^a-z0-9]+/gi,'-').toLowerCase()}.csv`;a.click();URL.revokeObjectURL(url)}
 function deleteSurvey(id){if(!window.confirm('Delete this survey and all its responses?'))return;saveAll(surveys.filter(s=>s.id!==id))}
 return <><PageTitle eyebrow="TOURNAMENT REGISTRATION & FEEDBACK" title="Tournament surveys." description="Create Google-Forms-style questionnaires, select exactly which members may apply, collect answers and export responses for Excel." action={<span className="today-chip"><ListChecks size={16}/> {canManage?`${surveys.length} surveys`: `${assignedSurvey.length} available to you`}</span>}/>
 {responseNotice&&<div className="notice"><Check size={16}/>{responseNotice}<button onClick={()=>setResponseNotice('')}><X size={15}/></button></div>}
 {canManage&&<form className="panel form-grid feature-form" onSubmit={createSurvey}><div className="wide-field"><h2 style={{margin:'0 0 6px'}}>Create a tournament survey</h2><p style={{margin:0,color:'#999',fontSize:12}}>A Level and B Level can choose the members allowed to apply. Add questions before publishing.</p></div><label>Survey / tournament name<input required value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Kerala Open Karate Tournament"/></label><label>Event label shown to members<input value={eventName} onChange={e=>setEventName(e.target.value)} placeholder="Tournament registration / travel plan"/></label><label className="wide-field">Description<textarea value={description} onChange={e=>setDescription(e.target.value)} rows="2" placeholder="Purpose, eligibility and instructions"/></label><label>Submission deadline<input type="date" value={deadline} onChange={e=>setDeadline(e.target.value)}/></label><div className="wide-field"><b style={{fontSize:12}}>Select eligible members ({targetIds.length} selected)</b><div className="survey-targets">{eligible.map(s=><label className="check-label" key={s.id}><input type="checkbox" checked={targetIds.includes(s.id)} onChange={e=>setTargetIds(prev=>e.target.checked?[...prev,s.id]:prev.filter(id=>id!==s.id))}/><span>{s.name} · {s.id} · {s.dojo}</span></label>)}</div><div className="inline-actions"><button type="button" className="btn secondary small-btn" onClick={()=>setTargetIds(eligible.map(s=>s.id))}>Select all eligible</button><button type="button" className="btn secondary small-btn" onClick={()=>setTargetIds([])}>Clear selection</button></div></div><div className="wide-field survey-question-builder"><b>Add questions</b><div className="form-grid"><label>Question<input value={questionText} onChange={e=>setQuestionText(e.target.value)} placeholder="e.g. Which weight category?"/></label><label>Answer type<select value={questionType} onChange={e=>setQuestionType(e.target.value)}><option>Short answer</option><option>Paragraph</option><option>Multiple choice</option><option>Checkboxes</option></select></label>{['Multiple choice','Checkboxes'].includes(questionType)&&<label className="wide-field">Options, separated by commas<input value={optionsText} onChange={e=>setOptionsText(e.target.value)} placeholder="Under 45kg, 45–55kg, Over 55kg"/></label>}<div className="form-actions"><button type="button" className="btn secondary" onClick={addQuestion}><Plus size={15}/> Add question</button></div></div>{draftQuestions.length>0&&<div className="survey-question-list">{draftQuestions.map((q,i)=><div key={q.id}><span>{i+1}. {q.text} <small>({q.type})</small></span><button type="button" className="text-button" onClick={()=>setDraftQuestions(prev=>prev.filter(x=>x.id!==q.id))}>Remove</button></div>)}</div>}</div><label className="check-label wide-field"><input type="checkbox" checked={uppercaseNames} onChange={e=>setUppercaseNames(e.target.checked)}/><span><b>Convert names to UPPERCASE in Excel/CSV export</b><small>Example: “akshay p s” → “AKSHAY P S”. This changes exported names only, not member profile names.</small></span></label><div className="form-actions"><button className="btn primary" disabled={!title.trim()||!targetIds.length||!draftQuestions.length}><ListChecks size={16}/> Publish survey</button></div></form>}
 <div className="survey-cards">{(canManage?surveys:assignedSurvey).map(survey=>{const myResponse=survey.responses.some(r=>r.memberId===session.id);const isClosed=survey.deadline&&survey.deadline<new Date().toISOString().slice(0,10);return <article className="panel survey-card" key={survey.id}><div className="survey-card-head"><div><span className="priority-chip">{survey.eventName||'Tournament survey'}</span><h2>{survey.title}</h2><p>{survey.description||'Please answer the questions below.'}</p><small>{survey.targetIds.length} eligible members · {survey.responses.length} responses{survey.deadline?` · Deadline ${survey.deadline}`:''}</small></div>{canManage&&<div className="inline-actions"><button className="btn secondary small-btn" onClick={()=>setResponsesOpen(p=>({...p,[survey.id]:!p[survey.id]}))}>{responsesOpen[survey.id]?'Hide responses':'View responses'}</button><button className="btn secondary small-btn" onClick={()=>exportResponses(survey)}><FileSpreadsheet size={14}/> Export Excel CSV</button><button className="btn secondary small-btn" onClick={()=>deleteSurvey(survey.id)}>Delete</button></div>}</div>
 {canManage&&responsesOpen[survey.id]&&<div className="table-wrap"><table><thead><tr><th>MEMBER ID</th><th>MEMBER NAME</th><th>SUBMITTED</th>{survey.questions.map(q=><th key={q.id}>{q.text}</th>)}</tr></thead><tbody>{survey.responses.map(r=><tr key={r.id}><td>{r.memberId}</td><td>{survey.uppercaseNames?String(r.memberName).toLocaleUpperCase('en-IN'):r.memberName}</td><td>{new Date(r.submittedAt).toLocaleString('en-IN')}</td>{survey.questions.map(q=><td key={q.id}>{r.answers.find(a=>a.questionId===q.id)?.answer||'—'}</td>)}</tr>)}</tbody></table>{!survey.responses.length&&<div className="empty-state">No responses received yet.</div>}</div>}
 {!canManage&&<>{myResponse?<div className="survey-submitted"><Check size={16}/> You have already submitted this survey.</div>:isClosed?<div className="survey-submitted">This survey is closed.</div>:<form className="survey-answer-form" onSubmit={e=>submitResponse(e,survey)}>{survey.questions.map((q,i)=><label key={q.id} className="survey-answer-question"><b>{i+1}. {q.text} <em>*</em></b>{q.type==='Paragraph'?<textarea required rows="3" value={answers[q.id]||''} onChange={e=>setAnswers(p=>({...p,[q.id]:e.target.value}))}/>:q.type==='Multiple choice'?<div className="survey-options">{q.options.map(opt=><label key={opt} className="check-label"><input type="radio" required name={`survey-${survey.id}-${q.id}`} checked={answers[q.id]===opt} onChange={()=>setAnswers(p=>({...p,[q.id]:opt}))}/>{opt}</label>)}</div>:q.type==='Checkboxes'?<div className="survey-options">{q.options.map(opt=><label key={opt} className="check-label"><input type="checkbox" checked={(answers[q.id]||[]).includes(opt)} onChange={e=>setAnswers(p=>({...p,[q.id]:e.target.checked?[...(p[q.id]||[]),opt]:(p[q.id]||[]).filter(v=>v!==opt)}))}/>{opt}</label>)}</div>:<input required value={answers[q.id]||''} onChange={e=>setAnswers(p=>({...p,[q.id]:e.target.value}))}/>}</label>)}<button className="btn primary"><Check size={15}/> Submit response</button></form>}</>}
 </article>})}{!(canManage?surveys:assignedSurvey).length&&<div className="empty-state panel">{canManage?'No surveys created yet. Create one above and select eligible members.':'No tournament surveys have been assigned to your account.'}</div>}</div><div className="feature-note"><Shield size={16}/> Prototype storage: surveys and responses are saved in this browser only. For multiple devices or truly private individual responses, connect a shared database and enforce permissions server-side.</div></>
}

function Reports({students,events,attendanceRecords,fees,grading,isA}) {
 const present=attendanceRecords.reduce((n,r)=>n+Object.values(r.statuses||{}).filter(v=>v==='Present').length,0);const absent=attendanceRecords.reduce((n,r)=>n+Object.values(r.statuses||{}).filter(v=>v==='Absent').length,0);const collected=fees.filter(f=>f.status==='Paid').reduce((n,f)=>n+Number(f.amount||0),0);
 function download(){const rows=[['Report','Value'],['Members',students.length],['Events',events.length],['Attendance sessions',attendanceRecords.length],['Present marks',present],['Absent marks',absent],['Fees collected (INR)',collected],['Belt assessments',grading.length]];const csv=rows.map(r=>r.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));a.download='wwmaa-summary-report.csv';a.click();URL.revokeObjectURL(a.href)}
 return <><PageTitle eyebrow="ASSOCIATION INTELLIGENCE" title="Reports & exports." description="A quick snapshot of the association's activity, attendance, fees and member development." action={<button className="btn primary" onClick={download}><Download size={16}/> Export CSV</button>}/><div className="stats-grid"><Stat icon={Users} label="Member profiles" value={students.length} note="Current directory"/><Stat icon={ClipboardCheck} label="Attendance sessions" value={attendanceRecords.length} note={`${present} present marks`}/><Stat icon={Receipt} label="Fees collected" value={'₹'+collected.toLocaleString('en-IN')} note="Recorded as paid"/><Stat icon={GraduationCap} label="Belt assessments" value={grading.length} note="Progress records"/></div><div className="panel report-panel"><div className="panel-toolbar"><div><h2>Operations snapshot</h2><p>Download a CSV to open in Excel or Google Sheets.</p></div><FileText size={22}/></div><div className="report-rows"><div><span>Upcoming events in portal</span><b>{events.length}</b></div><div><span>Attendance records saved</span><b>{attendanceRecords.length}</b></div><div><span>Present / absent marks</span><b>{present} / {absent}</b></div><div><span>Fees currently due</span><b>₹{fees.filter(f=>f.status==='Due').reduce((n,f)=>n+Number(f.amount||0),0).toLocaleString('en-IN')}</b></div><div><span>Successful grading results</span><b>{grading.filter(g=>g.result==='Passed').length}</b></div></div><p className="feature-note"><Shield size={16}/> {isA?'A Level reporting is available. This shared WWMAA database contains only data stored in this browser.':'Report totals are shown for the current preview; a production system should restrict financial reports to authorized roles.'}</p></div></>
}

function ControlTile({icon:Icon,title,text,status}) {return <div className="control-tile"><div className="control-tile-icon"><Icon size={19}/></div><div><h3>{title}</h3><p>{text}</p><span className="access-chip">{status}</span></div></div>}
function Modal({title,close,children}) {return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&close()}><div className="modal"><div className="modal-head"><div><div className="eyebrow">ASSOCIATION PORTAL</div><h2>{title}</h2></div><button className="icon-btn" onClick={close}><X size={19}/></button></div>{children}</div></div>}

const isDownloadHome = window.location.pathname === '/' || window.location.pathname === '/index.html'
createRoot(document.getElementById('root')).render(isDownloadHome ? <DownloadLanding /> : <App />)
