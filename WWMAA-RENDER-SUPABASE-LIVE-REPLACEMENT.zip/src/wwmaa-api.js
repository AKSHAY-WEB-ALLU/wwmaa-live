const API_BASE = (import.meta.env.VITE_WWMAA_API_URL || '').replace(/\/$/, '')

export async function wwmaaRequest(path, { method = 'GET', body, token } = {}) {
  if (!API_BASE) throw new Error('WWMAA backend URL is not configured. Set VITE_WWMAA_API_URL in Vercel.')
  const response = await fetch(`${API_BASE}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  })
  const data = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`)
  return data
}

export function loginWWMAA({ id, password, loginMode, previewRole }) {
  return wwmaaRequest('/api/auth/login', { method: 'POST', body: { id, password, loginMode, previewRole } })
}
